<?php
/**
 * Created by PhpStorm.
 * User: vladi
 * Date: 4.3.2017.
 * Time: 11.26
 */

namespace App;


use Illuminate\Database\Eloquent\Model;

class Package extends Model
{
    protected $table = 'packages';
}