$(document).ready(function() {
	
	var profileDisplay = $( ".profile-notifications-dropdown" ),
		navigationItem = $(".navigation-box"),
		profileDropdown = $(".profile-dropdown"),
		searchForm = $(".profile-search-form");

	// replace all form elements
	$(function() {
		jcf.replaceAll();
	});

	$( ".close-popup" ).click(function() {
		$( ".popup-wrapp" ).hide();
		// $( ".popup-overlay" ).hide();
	});

	$( ".open-login-popup" ).click(function() {
		$( ".login-popup-wrapp" ).show();
	});

	$( ".open-send-message" ).click(function(e) {
		e.preventDefault();
		/* Act on the event */
		var that = $(this);
		$('#to').val(that.data('sender'));
		// $( ".popup-overlay" ).show();
		$( "#send-message" ).show();
	});

	//open search form
	$( ".profile-search-trigger" ).click(function() {
	  $( ".profile-search-form" ).show();

	  $hideElements(profileDisplay);
	  $hideElements(profileDropdown);
	});


	//open profile
	$( ".profile-name" ).click(function() {
	  $( ".profile-dropdown" ).slideDown();
	  $hideElements(profileDisplay);
	  $hideSearch(searchForm);
	});
	$( "#profile-dropdown-close" ).click(function() {
	  $( ".profile-dropdown" ).slideUp();
	});

	// read more/less 
	$( ".review-read-more" ).click(function() {
	  $( ".review-read-more" ).css("display", "none");
	  $( ".review-read-less" ).css("display", "block");
	  $( ".review-text-hidden" ).slideDown();
	});
	$( ".review-read-less" ).click(function() {
	  $( ".review-read-more" ).css("display", "inline");
	  $( ".review-read-less" ).css("display", "none");
	  $( ".review-text-hidden" ).slideUp();
	});

	

	$( ".close-login-popup" ).click(function() {
		$( ".login-popup-wrapp" ).hide();
	});

	$( "#open-working-hours-popup").click(function(e) {
		e.preventDefault();
		// $( ".popup-overlay" ).show();
		$( "#working-hours-popup").show();
        // $('html, body').animate({
	    //     scrollTop: $("#working-hours-popup").offset().top - 50
	    // }, 2000);
	});
	$( "#add-images-click").click(function(e) {
		e.preventDefault();
		// $( ".popup-overlay" ).show();
		$( "#add-images-pop").show();
		// $('html, body').animate({
		// 	scrollTop: $("#working-hours-popup").offset().top - 50
		// }, 2000);
	});
	// datepicker
	// $( function() {
	//     $( ".datepicker" ).datepicker();
	// });

	//  open/close mobile menu
	$( ".navigation-trigger" ).click(function() {
	  $( ".navigation-wrapper" ).slideToggle();
	});

	//  open/close notifications menu
	$( "#notification-trigger" ).click(function() {
	  $( ".profile-notifications-dropdown" ).slideToggle();
	  $hideElements(profileDropdown);
	  $hideSearch(searchForm);
	});

	// open/close filters extend div
	$( "#filters-trigger" ).click(function() {
	  $( ".filters-expand" ).slideToggle();
	});

	// open/close address box
	$( ".results-address-trigger" ).click(function() {
	  $(this).siblings(".results-address-expand").slideToggle();
	});

	$( "#changeCategory" ).change(function() {
		advancedSearch();
	});
	$( "#changeCity" ).change(function() {
		advancedSearch();
	});
	$( "#nonstop" ).change(function() {
		advancedSearch();
	});
	$( "#delivery" ).change(function() {
		advancedSearch();
	});
	$( "#onlineBanking" ).change(function() {
		advancedSearch();
	});
	$( "#distanceSort" ).change(function() {
		advancedSearch();
	});
	$( ".remove-image-span" ).click(function() {
		window.location.replace(document.location.origin + "/delete/image/" + $(this).data('imageid'));
	});


	// Set up menu hover
	navigationItem.hover(function() {
		/* Stuff to do when the mouse enters the element */
		$(this).find('.navigation-dropdown-dec').css('display', 'block')
		$hideElements(profileDisplay);
	  	$hideElements(profileDropdown);
	  	$hideSearch(searchForm);

	}, function() {
		/* Stuff to do when the mouse leaves the element */
		$(this).find('.navigation-dropdown-dec').css('display', 'none')
	});

	

	//show/hide elements
	var $hideElements = function(element) {
		if(element.css('display') == 'block') {
	  		element.slideToggle();
	  	}	
	}

	var $hideSearch = function(element) {
		if(element.css('display') == 'block') {
	  		element.hide();
	  	}
	}
});

function advancedSearch() {
	var url 		= document.location.origin + document.location.pathname.slice(0,3);
	var town 		= $( "#changeCity" ).val();
	var category 	= $( "#changeCategory" ).val();
	var nonstop		= $('#nonstop').prop('checked');
	var delivery	= $('#delivery').prop('checked');
	var online		= $('#onlineBanking').prop('checked');
	var distSort	= $('#distanceSort').prop('checked');
	var distFilter	= $('#distanceFilter').val();

	if (town == null){town = "";}
	if (category == null){category = "";}

	nonstop != false ? 1 : 0;
	delivery != false ? 1 : 0;
	online != false ? 1 : 0;
	distSort != false ? 1 : 0;

	url = url + "/napredna-pretraga" + "?town=" + town + "&category=" + category + "&nonstop=" + nonstop;
	url = url + "&delivery=" + delivery + "&online=" + online + "&distSort=" + distSort + "&distFilter=" + distFilter;

	var userLocationData = localStorage.getItem('userLocationData');
	userLocationData = JSON.parse(userLocationData);

	if(userLocationData){
		url = url + "&lat=" + userLocationData.lat + "&lng=" + userLocationData.lng;
	}

	 window.location.replace(url);
}

