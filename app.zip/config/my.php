<?php
return  [
    'adminUrl' => 'https://admin.uzoni.rs'
];
?>