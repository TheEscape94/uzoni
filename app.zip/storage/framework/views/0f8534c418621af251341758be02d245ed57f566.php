<?php $__env->startSection('content'); ?>
    <section class="pull-left full-width user-profile">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 user-head">
                    <div class="user-image">
                        <?php if(isset($user->user_image)): ?>
                            <img src="/<?php echo e($user->user_image); ?>" alt="">
                        <?php else: ?>
                            <img src="/img/user/user-default.png" alt="">
                        <?php endif; ?>
                    </div>
                    <div class="user-data">
                        <p><?php echo e(\Auth::user()->name); ?> <?php echo e(\Auth::user()->lname); ?></p>
                        <div class="clr"></div>
                        <span><?php echo app('translator')->get('my.user'); ?></span>
                    </div>
                    <div class="user-data" style="padding-top: 15px;">
                        <form method="post" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <span style="margin-bottom: 5px;"><?php echo app('translator')->get('my.change_image'); ?></span>
                            <input type="file" name="userImage" onchange="this.form.submit()" placeholder="petar">
                        </form>
                    </div>
                </div>
            </div>
            
                
                    
                    
                        
                        
                        
                    
                    
                        
                        
                        
                    
                
            
        </div>
    </section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>