<?php $__env->startSection('content'); ?>
    <div class="main">
        <div class="container narrow">
            <div class="regitration-title-holder">
                <hr>
                <h1><?php echo app('translator')->get('my.registration_registration'); ?> <span><?php echo app('translator')->get('my.registration_company'); ?></span></h1>
            </div>
            <div class="registration-holder">
                <h2><?php echo app('translator')->get('my.basic_info'); ?>:</h2>
                <form action="<?php echo e(url('/register')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="is_company" value="1">
                    <div class="row">
                        <div class="col-lg-12">
                            <input type="text" name="company_name" class="form-control" placeholder="<?php echo app('translator')->get('my.company_name'); ?>">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <select name="category" id="1" class="form-control">
                                <option><?php echo app('translator')->get('my.category'); ?></option>
                                <?php $__currentLoopData = $mainCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($categry->id); ?>">
                                        <?php if(\Illuminate\Support\Facades\App::getLocale() == 'en'): ?>
                                            <?php echo e($categry->name_en); ?>

                                        <?php else: ?>
                                            <?php echo e($categry->name_rs); ?>

                                        <?php endif; ?>
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <input type="text" name="name" class="form-control" placeholder="<?php echo app('translator')->get('my.name'); ?>">
                        </div>
                        <div class="col-lg-6">
                            <input type="text" name="lname" class="form-control" placeholder="<?php echo app('translator')->get('my.lname'); ?>">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <input type="text" name="phone" class="form-control" placeholder="<?php echo app('translator')->get('my.phone'); ?>">
                        </div>
                        <div class="col-lg-6">
                            <input type="text" name="fax" class="form-control" placeholder="<?php echo app('translator')->get('my.fax_optional'); ?>">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <input type="text" name="address" class="form-control" placeholder="<?php echo app('translator')->get('my.address'); ?>">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <select name="town" id="select" class="form-control">
                                <option><?php echo app('translator')->get('my.town'); ?></option>
                                <?php $__currentLoopData = $towns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $town): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($town->id); ?>">
                                        <?php if(\Illuminate\Support\Facades\App::getLocale() == 'en'): ?>
                                            <?php echo e($town->name_en); ?>

                                        <?php else: ?>
                                            <?php echo e($town->name_rs); ?>

                                        <?php endif; ?>
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-lg-6">
                            <input type="text" name="zip" class="form-control" placeholder="<?php echo app('translator')->get('my.zip'); ?>">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-8">
                            <input type="text" name="pib" class="form-control" placeholder="<?php echo app('translator')->get('my.pib_optional'); ?>">
                        </div>
                        <div class="col-lg-4">
                            <input type="text" name="ident_numb" class="form-control" placeholder="<?php echo app('translator')->get('my.identificational_number_optional'); ?>">
                        </div>
                    </div>
                    <h2><?php echo app('translator')->get('my.access_data'); ?>:</h2>
                    <div class="row">
                        <div class="col-lg-12">
                            <input type="text" name="email" class="form-control" placeholder="Email">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <input type="text" name="password" class="form-control" placeholder="<?php echo app('translator')->get('my.password'); ?>">
                        </div>
                        <div class="col-lg-6">
                            <input type="text" name="password_repeat" class="form-control" placeholder="<?php echo app('translator')->get('my.password_repeat'); ?>">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <button class="btn btn-primary"><?php echo app('translator')->get('my.register'); ?></button>
                        </div>
                        <p>
                            <?php echo app('translator')->get('my.register_terms'); ?>
                        </p>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>