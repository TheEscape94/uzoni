<!DOCTYPE html>
<html>
<head>
    <title>Packs</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">

    <link rel="stylesheet" type="text/css" href="/css/bootstrap.css" />
    <link rel="stylesheet" type="text/css" href="/css/normalize.css" />
    <link rel="stylesheet" href="/css/jcf.css">
    <link rel="stylesheet" type="text/css" href="/css/main.css" />
    <link rel="stylesheet" type="text/css" href="/css/responsive.css" />

    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500,700,900" rel="stylesheet">

    <link rel="shortcut icon" href="/img/favicon.png" type="image/x-icon">
    <link rel="shortcut icon" href="/img/favicon.ico" type="image/x-icon">
    <link rel="icon" href="/img/favicon.ico" type="image/x-icon">

</head>
<body class="light">
<div class="body-container">
    <header class="full-width pull-left top-menu">
        <div class="container-big">
            <div class="row">
                <div class="col-xs-12">
                    <a href="<?php echo app('translator')->get('my.logo'); ?>" class="pull-left logo"><img src="/img/logo.jpg" /></a>
                    <div class="pull-right profile">
                        <div class="profile-search">
                            <div class="profile-search-trigger"></div>
                            <div class="profile-search-form">
                                <form>
                                    <input type="submit" name="" />
                                    <input type="text" name="" />
                                </form>
                            </div>
                        </div>
                        <a href="#" class="app-download">
                            <?php echo app('translator')->get('my.mobile_app'); ?><img src="/img/template-icons/app-download.png" />
                        </a>
                        <div class="profile-notifications profile-notifications-color">
                            <?php if(Auth::check()): ?>
                                <span id="notification-trigger">1<img src="/img/template-icons/notification-arrow-green.png"></span>
                            <?php endif; ?>
                            <div class="profile-notifications-dropdown">
                                <div class="pull-left full-width profile-notifications-arrow">
                                    <img src="/img/template-icons/notifications-dropdown.png" />
                                </div>
                                <h1 class="pull-left full-width profile-notifications-title">Poruke ( 1 )</h1>
                                <div class="clr"></div>
                                <ul class="pull-left full-width profile-notifications-list">
                                    <li>
                                        <a href="#">
                                            <div class="profile-notifications-image">
                                                <img src="/img/template-icons/app-download.png" />
                                            </div>
                                            <div class="profile-notifications-text">
                                                <h5>Pera Detlic</h5>
                                                <p><span>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
											tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
											quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
											consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
											cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
											proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</span></p>
                                            </div>
                                            <div class="profile-notifications-time">16:39</div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <div class="profile-notifications-image">
                                                <img src="/img/template-icons/app-download.png" />
                                            </div>
                                            <div class="profile-notifications-text">
                                                <h5>Pera Detlic</h5>
                                                <p><span>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
											tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
											quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
											consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
											cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
											proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</span></p>
                                            </div>
                                            <div class="profile-notifications-time">16:39</div>
                                        </a>
                                    </li>
                                </ul>
                                <div class="clr"></div>
                                <div class="pull-left full-width profile-notifications-all">
                                    <a href="#">Sve poruke</a>
                                </div>
                            </div>
                        </div>
                        <?php if(Auth::check()): ?>
                            <div class="profile-user">
                                <div class="full-width user">
                                    <span class="profile-name">Petar Petrovic</span>
                                    <div class="profile-dropdown">
                                        <div class="data">
                                            <div class="data-image">
                                                <img src="/img/template-icons/app-download.png" alt="" />
                                            </div>
                                            <div class="data-name">Petar Petrovic</div>
                                            <span id="profile-dropdown-close"><img src="/img/template-icons/dropdown-selector-close.png"></span>
                                        </div>
                                        <ul>
                                            <li>
                                                <a href="#">
                                                    <span>Podesavanje Profila</span>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <span>Podesavanja</span>
                                                </a>
                                            </li>
                                            <li class="logout">
                                                <a href="/">
                                                    <span>Odjava</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="profile-user">
                                <div class="full-width user">
                                    <span class="profile-name open-login-popup"><?php echo app('translator')->get('my.login_registration'); ?></span>
                                </div>
                            </div>
                        <?php endif; ?>
                        <div class="language">
                            <ul>
                                <?php
                                    if(\Illuminate\Support\Facades\App::getLocale() == 'en'){
                                ?>
                                    <li><a href="/en" class="active">En</a></li>
                                    <li><a href="/rs">Sr</a></li>
                                <?php
                                    }else{
                                ?>
                                    <li><a href="/en">En</a></li>
                                    <li><a href="/rs" class="active">Sr</a></li>
                                <?php
                                }?>

                            </ul>
                        </div>
                        <div class="social-network">
                            <ul>
                                <li>
                                    <a href="https://www.facebook.com" title="Facebook" target="_blank">
                                        <img src="/img/template-icons/facebook.png"/>
                                    </a>
                                </li>
                                <li>
                                    <a href="https://www.twitter.com" title="Twitter" target="_blank">
                                        <img src="/img/template-icons/twitter.png"/>
                                    </a>
                                </li>
                                <li>
                                    <a href="https://www.linkedin.com" title="LinkedIn" target="_blank">
                                        <img src="/img/template-icons/linkedin.png"/>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <div class="clr"></div>
    <section class="pull-left full-width navigation">
        <div class="container-big">
            <div class="navigation-trigger">
                <p><?php echo app('translator')->get('my.toggle_navigation'); ?></p>
                <div class="clr"></div>
                <span></span>
                <div class="clr"></div>
                <span></span>
            </div>
            <div class="row navigation-wrapper">
                <div class="col-xs-12">
                    <?php $__currentLoopData = $mainCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mainCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="navigation-box">
                            <a href="#" class="navigation-box-wrapp">
                                <div class="navigation-image">
                                    <img src="<?php echo e($adminUrl); ?>storage/app/public/<?php echo e($mainCategory->icon); ?>">
                                </div>
                                <?php if(\Illuminate\Support\Facades\App::getLocale() == 'en'): ?>
                                    <span><?php echo e($mainCategory->name_en); ?></span>
                                <?php else: ?>
                                    <span><?php echo e($mainCategory->name_rs); ?></span>
                                <?php endif; ?>
                            </a>
                            <div class="navigation-dropdown">
                                <div class="navigation-dropdown-dec"></div>
                                    <ul>
                                    <?php $__currentLoopData = $mainCategory->subGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a href="/rs/pretraga">
                                                <?php if(\Illuminate\Support\Facades\App::getLocale() == 'en'): ?>
                                                    <span><?php echo e($subGroup->name_en); ?></span>
                                                <?php else: ?>
                                                    <span><?php echo e($subGroup->name_rs); ?></span>
                                                <?php endif; ?>
                                            </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
    <div class="clr"></div>

    <?php echo $__env->yieldContent('content'); ?>

    <div class="clr"></div>
    <section class="pull-left full-width store">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-4 col-md-4">
                    <div class="store-img">
                        <img src="/img/google-store.jpg" alt="" />
                    </div>
                </div>
                <div class="col-xs-12 col-sm-8 col-md-8 store-text">
                    <h3>Preuzmite mobilnu aplikaciju</h3>
                    <div class="clr"></div>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                    <div class="clr"></div>
                    <a href="#" class="store-download">Preuzmi ovde</a>
                    <a href="#" class="store-logo"><img src="/img/google-store-logo.jpg" alt="Google Store" /></a>
                </div>
            </div>
        </div>
    </section>
    <div class="clr"></div>
    <section class="pull-left full-width footer-navigation">
        <div class="container-big">
            <div class="row">
                <div class="col-xs-12">
                    <ul>
                        <?php $__currentLoopData = $mainCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mainCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(\Illuminate\Support\Facades\App::getLocale() == 'en'): ?>
                                <li><a href="#"><?php echo e($mainCategory->name_en); ?></a></li>
                            <?php else: ?>
                                <li><a href="#"><?php echo e($mainCategory->name_rs); ?></a></li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <div class="clr"></div>
    <section class="pull-left full-width footer-subnavigation">
        <div class="container-big">
            <div class="row">
                <div class="col-xs-12">
                    <ul>
                        <li class="footer-subnavigation-title"><a href="#">Vodoinstalater</a></li>
                        <li><a href="#">Novi Sad</a></li>
                        <li><a href="#">Beograd</a></li>
                    </ul>
                    <ul>
                        <li class="footer-subnavigation-title"><a href="#">Elektricar</a></li>
                        <li><a href="#">Novi Sad</a></li>
                        <li><a href="#">Beograd</a></li>
                    </ul>
                    <ul>
                        <li class="footer-subnavigation-title"><a href="#">Popravka bele tehnike</a></li>
                        <li><a href="#">Novi Sad</a></li>
                        <li><a href="#">Beograd</a></li>
                    </ul>
                    <ul>
                        <li class="footer-subnavigation-title"><a href="#">Popravke rashladnih uredjaja</a></li>
                        <li><a href="#">Novi Sad</a></li>
                        <li><a href="#">Beograd</a></li>
                    </ul>
                    <ul>
                        <li class="footer-subnavigation-title"><a href="#">Popravke racunara</a></li>
                        <li><a href="#">Novi Sad</a></li>
                        <li><a href="#">Beograd</a></li>
                    </ul>
                    <ul>
                        <li class="footer-subnavigation-title"><a href="#">Servis mobilnih telefona</a></li>
                        <li><a href="#">Novi Sad</a></li>
                        <li><a href="#">Beograd</a></li>
                    </ul>
                    <ul>
                        <li class="footer-subnavigation-title"><a href="#">Bravar</a></li>
                        <li><a href="#">Novi Sad</a></li>
                        <li><a href="#">Beograd</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <div class="clr"></div>
    <footer>
        <div class="pull-left full-width footer-wrapp">
            <div class="container">
                <div class="row">
                    <div class="col-sm-4 col-md-3 footer-block">
                        <h5><?php echo app('translator')->get('my.contact'); ?></h5>
                        <div class="clr"></div>
                            <span class="line-dec"></span>
                        <div class="clr"></div>
                        <ul>
                            <li><a href="mailto:contact@uzoni.ts">contact@uzoni.rs</a></li>
                            <li><p>+000 123 4567</p></li>
                        </ul>
                    </div>
                    <div class="col-sm-4 col-md-3 footer-block">
                        <h5><?php echo app('translator')->get('my.about_us'); ?></h5>
                        <div class="clr"></div>
                            <span class="line-dec"></span>
                        <div class="clr"></div>
                        <ul>
                            <li><a href="#"><?php echo app('translator')->get('my.terms'); ?></a></li>
                            <li><a href="#"><?php echo app('translator')->get('my.payment_method'); ?></a></li>
                            <li><a href="#"><?php echo app('translator')->get('my.packages'); ?></a></li>
                        </ul>
                    </div>
                    <div class="col-sm-4 col-md-3 footer-block">
                        <h5><?php echo app('translator')->get('my.social_networks'); ?></h5>
                        <div class="clr"></div>
                            <span class="line-dec"></span>
                        <div class="clr"></div>
                        <ul>
                            <li>
                                <a href="https://www.facebook.com" title="Facebook" target="_blank">Facebook</a>
                            </li>
                            <li>
                                <a href="https://www.twitter.com" title="Twitter" target="_blank">Twitter</a>
                            </li>
                            <li>
                                <a href="https://www.linkedin.com" title="LinkedIn" target="_blank">Linkedin</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="row copyrights">
                    <div class="col-xs-12">
                        <p>@<?= date("Y") ?> uzoni.rs</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</div>


<div class="login login-popup-wrapp">
    <form>
        <div class="close close-login-popup">
            <img src="/img/template-icons/close.png"/>
        </div>
        <div class="pull-left full-width form-group-wrapp">
            <div class="pull-left full-width form-group">
                <input type="text" name="" placeholder="E-mail" />
            </div>
            <div class="pull-left full-width form-group">
                <input type="password" name="" placeholder="Sifra" />
            </div>
            <div class="pull-left full-width form-group">
                <input type="submit" name="" value="Prijava" />
            </div>
            <div class="pull-left full-width form-group password">
                <a href="#" class="forgot-password">Zaboravili ste sifru?</a>
                <div class="form-group-checkbox pull-right">
                    <input type="checkbox" id="chk1" />
                    <label title="Unchecked state" for="chk1">Zapamti me</label>
                </div>
            </div>
        </div>
        <div class="pull-left full-width create-options">
            <a href="#" id="create-account">Napravi nalog</a>
            <ul class="login-list pull-left full-width">
                <?php if(\Illuminate\Support\Facades\App::getLocale() == 'en'): ?>
                    <li>
                        <a href="/en/registracija-firme">
                            As <br/><span>EMPLOYER</span>
                        </a>
                    </li>
                    <li class="divider"></li>
                    <li>
                        <a href="/en/registracija">
                            As<br/><span>USER</span>
                        </a>
                    </li>
                <?php else: ?>
                    <li>
                        <a href="/rs/registracija-firme">
                            Kao <br/><span>POSLODAVAC</span>
                        </a>
                    </li>
                    <li class="divider"></li>
                    <li>
                        <a href="/rs/registracija">
                            Kao <br/><span>KORISNIK</span>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
        <div class="pull-left full-width social-account" style="display: none;">
            <a href="#" id="create-account">Napravi nalog</a>
            <p class="pull-left full-width social-account-text">Prijavi se preko društvene mreže:</p>
            <ul class="login-list pull-left full-width">
                <li>
                    <a href="#">
                        <img src="/img/template-icons/facebook-login.png" alt="Facebook" />
                    </a>
                </li>
                <li class="divider"></li>
                <li>
                    <a href="#">
                        <img src="/img/template-icons/google-login.png" alt="Google" />
                    </a>
                </li>
            </ul>
        </div>
    </form>
</div>

<script type="text/javascript" src="/js/jquery.js"></script>
<script type="text/javascript" src="/js/main.js"></script>
<script src="/js/jquery.js"></script>
<script src="/js/jcf.js"></script>
<script src="/js/jcf.file.js"></script>
<script src="/js/jcf.radio.js"></script>
<script src="/js/jcf.range.js"></script>
<script src="/js/jcf.button.js"></script>
<script src="/js/jcf.number.js"></script>
<script src="/js/jcf.select.js"></script>
<script src="/js/jcf.checkbox.js"></script>
<script src="/js/jcf.textarea.js"></script>
<script src="/js/jcf.scrollable.js"></script>
</body>
</html>
