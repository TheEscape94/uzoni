<?php $__env->startSection('content'); ?>
    <div class="main">
        <div class="container narrow">
            <div class="regitration-title-holder">
                <hr>
                <h1><?php echo app('translator')->get('my.registration_registration'); ?> <span><?php echo app('translator')->get('my.registration_user'); ?></span></h1>
            </div>
            <div class="registration-holder">
                <h2><?php echo app('translator')->get('my.basic_info'); ?>:</h2>
                <form role="form" method="POST" action="<?php echo e(url('/register')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <div class="row">
                        <?php if($errors->has('name')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('name')); ?></strong>
                            </span>
                        <?php endif; ?>
                        <div class="col-lg-6">
                            <input type="text" name="name" class="form-control" placeholder="<?php echo app('translator')->get('my.name'); ?>">
                        </div>
                        <?php if($errors->has('lname')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('lname')); ?></strong>
                            </span>
                        <?php endif; ?>
                        <div class="col-lg-6">
                            <input type="text" name="lname" class="form-control" placeholder="<?php echo app('translator')->get('my.lname'); ?>">
                        </div>
                    </div>
                    <div class="row">
                        <?php if($errors->has('town')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('town')); ?></strong>
                            </span>
                        <?php endif; ?>
                        <div class="col-lg-12">
                            <select name="town" id="select" class="form-control">
                                <option value="1"><?php echo app('translator')->get('my.town'); ?></option>
                                <?php $__currentLoopData = $towns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $town): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($town->id); ?>">
                                        <?php if(\Illuminate\Support\Facades\App::getLocale() == 'en'): ?>
                                            <?php echo e($town->name_en); ?>

                                        <?php else: ?>
                                            <?php echo e($town->name_rs); ?>

                                        <?php endif; ?>
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <h2><?php echo app('translator')->get('my.access_data'); ?>:</h2>
                    <div class="row">
                        <?php if($errors->has('email')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>
                        <div class="col-lg-12">
                            <input type="text" name="email" class="form-control" placeholder="Email">
                        </div>
                    </div>
                    <div class="row">
                        <?php if($errors->has('password')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        <?php endif; ?>
                        <div class="col-lg-6">
                            <input type="password" name="password" class="form-control" placeholder="<?php echo app('translator')->get('my.password'); ?>">
                        </div>
                        <?php if($errors->has('password_repeat')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('password_repeat')); ?></strong>
                            </span>
                        <?php endif; ?>
                        <div class="col-lg-6">
                            <input type="password" name="password_repeat" class="form-control" placeholder="<?php echo app('translator')->get('my.password_repeat'); ?>">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <button class="btn btn-primary"><?php echo app('translator')->get('my.register'); ?></button>
                        </div>
                        <p>
                            <?php echo app('translator')->get('my.register_terms'); ?>
                        </p>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>