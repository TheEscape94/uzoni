<?php $__env->startSection('content'); ?>
    <section class="pull-left full-width user-profile">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 user-head">
                    <div class="user-image">
                        <img src="/img/user/user-default.png"  alt="" />
                        <div class="user-level"><img src="/img/user/level-gold.png"  alt="" /></div>
                    </div>
                    <div class="user-data">
                        <p>Petar Petrovic</p>
                        <div class="clr"></div>
                        <span>Vodointstalater</span>
                        <div class="clr"></div>
                        <ul>
                            <li>Elektricar</li>
                            <li>Bravar</li>
                        </ul>
                    </div>
                    <div class="rate">
                        <ul>
                            <li class="rated"></li>
                            <li class="rated"></li>
                            <li class="rated"></li>
                            <li class="rated"></li>
                            <li class=""></li>
                        </ul>
                        <div class="clr"></div>
                        <span>4.0</span>
                    </div>
                    <div class="pull-right send-message">
                        <a href="#">Posalji poruku</a>
                    </div>
                </div>
            </div>
            <div class="row user-contacts">
                <div class="col-sm-4 col-md-4 address">
                    <h5>Kontakt</h5>
                    <div class="clr"></div>
                    <ul>
                        <li>
                            <p><span>Novi Sad</span></p>
                            <p>Narodnog Fronta 59</p>
                            <p><span>064</span> 1234567, <span>063</span> 1234567</p>
                        </li>
                    </ul>
                    <ul>
                        <li>
                            <p><span>Novi Sad</span></p>
                            <p>Narodnog Fronta 59</p>
                            <p><span>064</span> 1234567, <span>063</span> 1234567</p>
                        </li>
                    </ul>
                    <ul>
                        <li>
                            <p><span>Novi Sad</span></p>
                            <p>Narodnog Fronta 59</p>
                            <p><span>064</span> 1234567, <span>063</span> 1234567</p>
                        </li>
                    </ul>
                </div>
                <div class="col-md-8 col-md-8 text">
                    <h2><span>Info</span></h2>
                    <p>Lorem ipsum dolor sit amet, eum erant corpora delicatissimi ei, at usu denique salutatus, magna alienum te mei. Sed impetus feugiat no, at eius suscipit molestiae pri. Probo assum ei has, at qui summo discere impedit, et nusquam nostrum vis. Ne vis tollit gubergren. Oblique fabellas luptatum ut eos, sea at eruditi accusata tincidunt.  Lorem ipsum dolor sit amet, eum erant corpora delicatissimi ei, at usu denique salutatus, magna alienum te mei. Sed impetus feugiat no, at eius suscipit molestiae pri. Probo assum ei has, at qui summo discere impedit, et nusquam nostrum vis. Ne vis tollit gubergren. Oblique fabellas luptatum ut eos, sea at eruditi accusata tincidunt.</p>
                </div>
            </div>
            <div class="row user-map">
                <div class="col-xs-12">
                    <div id="map"></div>
                </div>
            </div>
            <div class="row user-data-list">
                <div class="col-sm-4 col-md-4 user-data-list-box">
                    <h5>Sajt</h5>
                    <ul>
                        <li><a href="#">www.imesajta.com</a></li>
                    </ul>
                </div>
                <div class="col-sm-4 col-md-4 social user-data-list-box">
                    <h5>Drustvene mreze</h5>
                    <ul>
                        <li><a href="#"><img src="/img/template-icons/facebook.png" alt="Facebook"></a></li>
                        <li><a href="#"><img src="/img/template-icons/twitter.png" alt="Twitter"></a></li>
                        <li><a href="#"><img src="/img/template-icons/pinterest.png" alt="Pinterest"></a></li>
                    </ul>
                </div>
                <div class="col-sm-4 col-md-4 user-data-list-box">
                    <h5>Radno vreme</h5>
                    <ul>
                        <li>
                            <p>Ponedeljak</p>
                            <span>08-16h</span>
                        </li>
                        <li>
                            <p>Utorak</p>
                            <span>08-16h</span>
                        </li>
                        <li>
                            <p>Sreda</p>
                            <span>08-16h</span>
                        </li>
                        <li>
                            <p>Cetvrtak</p>
                            <span>08-16h</span>
                        </li>
                        <li>
                            <p>Petak</p>
                            <span>08-16h</span>
                        </li>
                        <li>
                            <p>Subota</p>
                            <span>08-16h</span>
                        </li>
                        <li>
                            <p>Nedelja</p>
                            <span>08-16h</span>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="row user-media-head">
                <div class="col-xs-12">
                    <h3 class="pull-left" >Galerija</h3>
                    <p class="pull-left user-media-count">(4/20)</p>
                    <a class="pull-right user-media-add" href="#">Dodaj sliku</a>
                </div>
            </div>
            <div class="row user-media-body">
                <div class="col-xs-12 col-sm-3 col-md-3 user-media-body-image">
                    <div class="user-media-image"><img src="/img/template-icons/not-found.png"></div>
                </div>
                <div class="col-xs-12 col-sm-3 col-md-3 user-media-body-image">
                    <div class="user-media-image"></div>
                </div>
                <div class="col-xs-12 col-sm-3 col-md-3 user-media-body-image">
                    <div class="user-media-image"></div>
                </div>
                <div class="col-xs-12 col-sm-3 col-md-3 user-media-body-image">
                    <div class="user-media-image"></div>
                </div>
            </div>
            <div class="clr"></div>
            <div class="row user-media-head">
                <div class="col-xs-12">
                    <h3 class="pull-left" >Video</h3>
                    <p class="pull-left user-media-count">(4/20)</p>
                    <a class="pull-right user-media-add" href="#">Dodaj video</a>
                </div>
            </div>
            <div class="row user-media-body">
                <div class="col-xs-12 col-sm-6 col-md-6 user-media-body-image">
                    <div class="user-media-image"></div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-6 user-media-body-image">
                    <div class="user-media-image"></div>
                </div>
            </div>
            <div class="row user-reviews">
                <div class="col-xs-12">
                    <h3 class="pull-left">Ocene korisnika</h3>
                    <div class="clr"></div>
                    <form class="pull-left full-width">
                        <input type="text" name="" placeholder="Napisi komentar..." />
                    </form>
                    <div class="pull-left full-width review-box">
                        <div class="review-img">
                            <img src="/img/template-icons/search-icon.png" alt="" />
                        </div>
                        <div class="review-data">
                            <p class="pull-left full-width review-name">Pera Detlic</p>
                            <span class="pull-left full-width review-date">24.10.2016</span>
                            <div class="pull-left full-width review-text">Lorem ipsum dolor sit amet, iriure erroribus et cum, te sit debet utroque. At blandit dissentiunt vituperatoribus eum, an eos quaeque mediocritatem. Ne prompta tacimates abhorreant eos, pro ei magna fugit, ut tollit utinam incorrupte usu. Et nominavi expetenda intellegebat sed, reque numquam ex sit.</div>
                        </div>
                        <div class="pull-right rate">
                            <ul>
                                <li class="rated"></li>
                                <li class="rated"></li>
                                <li class="rated"></li>
                                <li class="rated"></li>
                                <li class=""></li>
                            </ul>
                        </div>
                    </div>
                    <div class="pull-left full-width review-box">
                        <div class="review-img">
                            <img src="/img/template-icons/search-icon.png" alt="" />
                        </div>
                        <div class="review-data">
                            <p class="pull-left full-width review-name">Pera Detlic</p>
                            <span class="pull-left full-width review-date">24.10.2016</span>
                            <div class="pull-left full-width review-text">Lorem ipsum dolor sit amet, iriure erroribus et cum, te sit debet utroque. At blandit dissentiunt vituperatoribus eum, an eos quaeque mediocritatem. Ne prompta tacimates abhorreant eos, pro ei magna fugit, ut tollit utinam incorrupte usu. Et nominavi expetenda intellegebat sed, reque numquam ex sit. Meis verear mei at. Lorem ipsum dolor sit amet, iriure erroribus et cum, te sit debet utroque. At blandit dissentiunt vituperatoribus eum, an eos quaeque mediocritatem. Ne prompta tacimates abhorreant eos, pro ei magna fugit, ut tollit utinam incorrupte usu. Et nominavi expetenda intellegebat sed, reque numquam ex sit. Meis verear mei at.<span class="review-read-more"><br/>+ Procitaj vise iliti klikni da vidis funckionalnost<br/></span><span class="review-text-hidden">Lorem ipsum dolor sit amet, iriure erroribus et cum, te sit debet utroque. At blandit dissentiunt vituperatoribus eum, an eos quaeque mediocritatem. Ne prompta tacimates abhorreant eos, pro ei magna fugit, ut tollit utinam incorrupte usu. Et nominavi expetenda intellegebat sed, reque numquam ex sit. Meis verear mei at. Lorem ipsum dolor sit amet, iriure erroribus et cum, te sit debet utroque. At blandit dissentiunt vituperatoribus eum, an eos quaeque mediocritatem. Ne prompta tacimates abhorreant eos, pro ei magna fugit, ut tollit utinam incorrupte usu. Et nominavi expetenda intellegebat sed, reque numquam ex sit. Meis verear mei at.</span><span class="review-read-less"><br/>- Sakri text<br/></span></div>


                        </div>
                        <div class="pull-right rate">
                            <ul>
                                <li class="rated"></li>
                                <li class="rated"></li>
                                <li class="rated"></li>
                                <li class="rated"></li>
                                <li class=""></li>
                            </ul>
                        </div>
                    </div>
                    <div class="pull-left full-width review-box">
                        <div class="review-img">
                            <img src="/img/template-icons/search-icon.png" alt="" />
                        </div>
                        <div class="review-data">
                            <p class="pull-left full-width review-name">Pera Detlic</p>
                            <span class="pull-left full-width review-date">24.10.2016</span>
                            <div class="pull-left full-width review-text">Lorem ipsum dolor sit amet, iriure erroribus et cum, te sit debet utroque. At blandit dissentiunt vituperatoribus eum, an eos quaeque mediocritatem. Ne prompta tacimates abhorreant eos, pro ei magna fugit, ut tollit utinam incorrupte usu. Et nominavi expetenda intellegebat sed, reque numquam ex sit.</div>
                        </div>
                        <div class="pull-right rate">
                            <ul>
                                <li class="rated"></li>
                                <li class="rated"></li>
                                <li class="rated"></li>
                                <li class="rated"></li>
                                <li class=""></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row full-width pagination">
                <div class="col-xs-12">
                    <ul class="pull-left full-width">
                        <li class="active"><a href="#">1</a></li>
                        <li><a href="#">2</a></li>
                        <li><a href="#">3</a></li>
                        <li><a href="#">4</a></li>
                        <li><a href="#">5</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>