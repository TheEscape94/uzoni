<?php $__env->startSection('content'); ?>
    <section class="pull-left full-width register">
        <div class="full-width register-background"></div>
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="register-head">
                        <span class="register-dec"></span>
                        <div class="clr"></div>
                        <p><?php echo app('translator')->get('my.registration_registration'); ?> <br/><span><?php echo app('translator')->get('my.registration_company'); ?></span></p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12">
                    <div class="register-body">
                        <form action="<?php echo e(url('/register')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="is_company" value="1">
                            <h2><?php echo app('translator')->get('my.basic_info'); ?>:</h2>
                            <div class="form-group">
                                <input type="text" name="company_name" value="<?php echo e(old('company_name')); ?>" placeholder="<?php echo app('translator')->get('my.company_name'); ?>">
                                <?php if($errors->has('company_name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('company_name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <select name="category">
                                    <option selected disabled><?php echo app('translator')->get('my.category'); ?></option>
                                    <?php $__currentLoopData = $mainCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($categry->id); ?>">
                                            <?php if(\Illuminate\Support\Facades\App::getLocale() == 'en'): ?>
                                                <?php echo e($categry->name_en); ?>

                                            <?php else: ?>
                                                <?php echo e($categry->name_rs); ?>

                                            <?php endif; ?>
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('category')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('category')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group half">
                                <input type="text" name="name" value="<?php echo e(old('name')); ?>" placeholder="<?php echo app('translator')->get('my.name'); ?>">
                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="pull-right form-group half">
                                <input type="text" name="lname" value="<?php echo e(old('lname')); ?>" placeholder="<?php echo app('translator')->get('my.lname'); ?>">
                                <?php if($errors->has('lname')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('lname')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group half">
                                <input type="text" name="phone" value="<?php echo e(old('phone')); ?>" placeholder="<?php echo app('translator')->get('my.phone'); ?>">
                                <?php if($errors->has('phone')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('phone')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <style>
                                .optional-input input::-webkit-input-placeholder { /* WebKit, Blink, Edge */
                                    color: #a8a8a8;
                                }
                            </style>
                            <div class="pull-right form-group half optional-input">
                                <input type="text" name="fax" value="<?php echo e(old('fax')); ?>" placeholder="<?php echo app('translator')->get('my.fax_optional'); ?>">
                            </div>
                            <div class="form-group">
                                <input type="text" name="address" value="<?php echo e(old('address')); ?>" placeholder="<?php echo app('translator')->get('my.address'); ?>">
                                <?php if($errors->has('address')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('address')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group two-third">
                                <select name="town">
                                    <option><?php echo app('translator')->get('my.town'); ?></option>
                                    <?php $__currentLoopData = $towns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $town): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($town->id); ?>">
                                            <?php if(\Illuminate\Support\Facades\App::getLocale() == 'en'): ?>
                                                <?php echo e($town->name_en); ?>

                                            <?php else: ?>
                                                <?php echo e($town->name_rs); ?>

                                            <?php endif; ?>
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('town')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('town')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="pull-right form-group one-third">
                                <input type="text" name="zip" value="<?php echo e(old('zip')); ?>" placeholder="<?php echo app('translator')->get('my.zip'); ?>">
                                <?php if($errors->has('zip')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('zip')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <h2><?php echo app('translator')->get('my.access_data'); ?>:</h2>
                            <div class="form-group">
                                <input type="text" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email">
                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group half">
                                <input type="password" name="password" placeholder="<?php echo app('translator')->get('my.password'); ?>">
                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="pull-right form-group half">
                                <input type="password" name="password_repeat" placeholder="<?php echo app('translator')->get('my.password_repeat'); ?>">
                                <?php if($errors->has('password_repeat')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password_repeat')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <input type="submit" name="register" value="<?php echo app('translator')->get('my.register'); ?>">
                            </div>
                            <div class="register-note">
                                <p><?php echo app('translator')->get('my.register_note'); ?></p>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>