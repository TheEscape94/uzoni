
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Bootstrap 101 Template</title>
    <!-- Bootstrap -->
    <link href="<?php echo e(url('/')); ?>/bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(url('/')); ?>/assets/css/style.css" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Rubik" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<div class="header">
    <div class="container">
        <div class="row">
            <div class="col-sm-6 col-xs-12">
                <div class="logo">
                    <h1><?php echo app('translator')->get('my.logo'); ?></h1>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="hidden-xs text-right">
                    <div class="social">
                        <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                        <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                        <a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                    </div>
                    <div class="actions">
                        <a href="#" class="search"><i class="fa fa-search" aria-hidden="true"></i></a>
                        <a href="#" class="app"><?php echo app('translator')->get('my.mobile_app'); ?> <i class="fa fa-mobile" aria-hidden="true"></i></a>
                        <?php if(!Auth::check()): ?>
                            <a href="#" class="reg" data-toggle="modal" data-target="#login-modal"><?php echo app('translator')->get('my.login_registration'); ?></a>
                        <?php else: ?>
                            <a href="<?php echo e(url('/')); ?>/<?php echo app('translator')->get('routes.profile'); ?>"><?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->lname); ?></a>
                        <?php endif; ?>
                        <?php
                        $langActiveClass = '';
                        if(\Illuminate\Support\Facades\App::getLocale() == 'en'){
                        ?>
                            <a href="<?php echo e(url('/')); ?>/en" class="lang active">En</a>
                            <a href="<?php echo e(url('/')); ?>/rs" class="lang">Sr</a>
                        <?php
                        }else{
                        ?>
                            <a href="<?php echo e(url('/')); ?>/en" class="lang">En</a>
                            <a href="<?php echo e(url('/')); ?>/rs" class="lang active">Sr</a>
                        <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<nav class="navbar navbar-default">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only"><?php echo app('translator')->get('my.toggle_navigation'); ?></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <!--<a class="navbar-brand" href="#">Brand</a>-->
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <?php $__currentLoopData = $mainCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mainCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <img src="<?php echo e($adminUrl); ?>storage/app/public/<?php echo e($mainCategory->icon); ?>">
                            <?php if(\Illuminate\Support\Facades\App::getLocale() == 'en'): ?>
                                <?php echo e($mainCategory->name_en); ?>

                            <?php else: ?>
                                <?php echo e($mainCategory->name_rs); ?>

                            <?php endif; ?>
                        </a>
                        <?php if(count($mainCategory->subGroups) > 0): ?>
                        <ul class="dropdown-menu">
                            <?php $__currentLoopData = $mainCategory->subGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="#">
                                        <?php if(\Illuminate\Support\Facades\App::getLocale() == 'en'): ?>
                                            <?php echo e($subGroup->name_en); ?>

                                        <?php else: ?>
                                            <?php echo e($subGroup->name_rs); ?>

                                        <?php endif; ?>
                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php endif; ?>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</nav>
<?php echo $__env->yieldContent('content'); ?>
<footer>
    <div class="top-footer">
        <div class="container categories">
            <?php $__currentLoopData = $mainCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mainCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href=""><?php echo e($mainCategory->name); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <hr>
        <div class="container subcategories">
            <div class="row">
                <div class="col-lg-2">
                    <a href="">Elektricar</a>
                </div>
                <div class="col-lg-2">
                    <a href="">link 3</a>
                </div>
                <div class="col-lg-2">
                    <a href="">link 4</a>
                </div>
                <div class="col-lg-2">
                    <a href="">link 5</a>
                </div>
                <div class="col-lg-2">
                    <a href="">link 6</a>
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-lg-2">
                    <a href="">Beograd</a>
                </div>
                <div class="col-lg-2">
                    <a href="">Beograd</a>
                </div>
                <div class="col-lg-2">
                    <a href="">Beograd</a>
                </div>
                <div class="col-lg-2">
                    <a href="">Beograd</a>
                </div>
                <div class="col-lg-2">
                    <a href="">Beograd</a>
                </div>
                <div class="col-lg-2">
                    <a href="">Beograd</a>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-2">
                    <a href="">Novi Sad</a>
                </div>
                <div class="col-lg-2">
                    <a href="">Novi Sad</a>
                </div>
                <div class="col-lg-2">
                    <a href="">Novi Sad</a>
                </div>
                <div class="col-lg-2">
                    <a href="">Novi Sad</a>
                </div>
                <div class="col-lg-2">
                    <a href="">Novi Sad</a>
                </div>
                <div class="col-lg-2">
                    <a href="">Novi Sad</a>
                </div>
            </div>
        </div>
    </div>
    <div class="bottom-footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 relative">
                    <h3><?php echo app('translator')->get('my.contact'); ?></h3>
                    <hr class="border">
                    <ul class="list-unstyled">
                        <li><p>contact@uzoni.com</p></li>
                        <li><p>+000 123 5678</p></li>
                    </ul>
                </div>
                <div class="col-lg-3 relative">
                    <h3><?php echo app('translator')->get('my.about_us'); ?></h3>
                    <hr class="border">
                    <ul class="list-unstyled">
                        <li><p><?php echo app('translator')->get('my.about_us'); ?></p></li>
                        <li><p><?php echo app('translator')->get('my.payment_method'); ?></p></li>
                        <li><p><a href="<?php echo e(url('/')); ?>/paketi"><?php echo app('translator')->get('my.packages'); ?></a></p></li>
                    </ul>
                </div>
                <div class="col-lg-3 relative">
                    <h3><?php echo app('translator')->get('my.social_networks'); ?></h3>
                    <hr class="border">
                    <ul class="list-unstyled">
                        <li><p>Facebook</p></li>
                        <li><p>Twitter</p></li>
                        <li><p>Instagram</p></li>
                    </ul>
                </div>
            </div>
            <p class="footer-credentials"><?php echo e('@'); ?><?php echo e(date('Y')); ?> uzoni.rs</p>
        </div>
    </div>
</footer>

<!-- Modal -->
<?php if($errors->first('password') || $errors->first('email')): ?>
    <?php
        $fadeIn = 'in';
        $display = 'block';
    ?>
<?php else: ?>
    <?php
    $fadeIn = '';
    $display = 'none';
    ?>
<?php endif; ?>
<div class="modal fade <?php echo e($fadeIn); ?>" id="login-modal" role="dialog" style="display: <?php echo e($display); ?>">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <?php if($errors->first('password')): ?>
                <?php echo e($errors->first('password')); ?>

            <?php endif; ?>
            <?php if($errors->first('email')): ?>
                <?php echo e($errors->first('email')); ?>

            <?php endif; ?>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <div class="modal-body">
                <form role="form" method="POST" action="<?php echo e(url('/login')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <div class="row">
                        <div class="col-lg-12">
                            <input type="text" name="email" class="form-control" placeholder="E-mail">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <input type="password" name="password" class="form-control" placeholder="Sifra">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <button class="btn btn-primary"><?php echo app('translator')->get('my.sign_in'); ?></button>
                        </div>
                        <a href="#"><?php echo app('translator')->get('my.password_reset'); ?></a>
                        <label for="forgot-pass">
                            <input type="checkbox" id="forgot-pass">
                            <?php echo app('translator')->get('my.remember_me'); ?>
                        </label>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <div class="row">
                    <div class="col-lg-12">
                        <a href="<?php echo e(url('/')); ?>/<?php echo app('translator')->get('routes.registration'); ?>" class="btn btn-inverse"><?php echo app('translator')->get('my.create_account'); ?></a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <a href="<?php echo e(url('/')); ?>/<?php echo app('translator')->get('routes.company_registration'); ?>" class="btn btn-inverse"><?php echo app('translator')->get('my.create_company_account'); ?></a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <button class="btn btn-facebook">facebook</button>
                    </div>
                    <div class="col-lg-6">
                        <button class="btn btn-google">Google+</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?php echo e(url('/')); ?>/bower_components/jquery/dist/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="<?php echo e(url('/')); ?>/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
</body>
</html>

