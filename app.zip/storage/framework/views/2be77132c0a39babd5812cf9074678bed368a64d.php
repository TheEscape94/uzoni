<?php $__env->startSection('content'); ?>
    <section class="pull-left full-width register">
        <div class="full-width register-background"></div>
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="register-head">
                        <span class="register-dec"></span>
                        <div class="clr"></div>
                        <?php if(\Illuminate\Support\Facades\App::getLocale() == 'en'): ?>
                            <p>Profile <br/><span>Settings</span></p>
                        <?php else: ?>
                            <p>Podesavanje <br/><span>Profila</span></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12">
                    <div class="register-body">
                        <div class="form-group">
                            <form method="post" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <label><?php echo app('translator')->get('my.change_image'); ?></label><br>
                                <input type="file" name="userImage" onchange="this.form.submit()">
                                <?php if(isset($companyDetail->user->user_image)): ?>
                                    <img src="/<?php echo e($companyDetail->user->user_image); ?>" style="margin: -45px 0 0 50px;">
                                <?php endif; ?>
                            </form>
                        </div>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <div class="form-group">
                            <form method="post" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <label><?php echo app('translator')->get('my.add_images'); ?></label><br>
                                <input type="file" name="optionalImage" onchange="this.form.submit()">
                                <br>
                                <br>
                                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <img width="96" src="/<?php echo e($image->user_image); ?>">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </form>
                        </div>

                        <div class="register-note">
                            <p></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>