<?php $__env->startSection('content'); ?>
    <section class="pull-left full-width user-profile">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 user-head">
                    <div class="user-image">
                        <?php if(isset($companyDetail->user->user_image)): ?>
                            <img src="/<?php echo e($companyDetail->user->user_image); ?>" alt="">
                        <?php else: ?>
                            <img src="/img/user/user-default.png" alt="">
                        <?php endif; ?>
                        <div class="user-level"><img src="/img/user/level-gold.png"  alt="" /></div>
                    </div>
                    <div class="user-data">
                        <p><?php echo e($companyDetail->company_name); ?></p>
                        <div class="clr"></div>
                        <span><?php if(isset($companyDetail->categoryRelation)): ?><?php echo e($companyDetail->categoryRelation->name_rs); ?><?php endif; ?></span>
                        <div class="clr"></div>
                        <ul>
                            <?php if(isset($companyDetail->category2Relation)): ?><li><?php echo e($companyDetail->category2Relation->name_rs); ?></li><?php endif; ?>
                            <?php if(isset($companyDetail->category3Relation)): ?><li><?php echo e($companyDetail->category3Relation->name_rs); ?></li><?php endif; ?>
                        </ul>
                    </div>
                    
                        
                            
                            
                            
                            
                            
                        
                        
                        
                    
                    <?php if(Auth::user() != null && Auth::user()->id != $companyDetail->user->id): ?>
                        <div class="pull-right send-message">
                            <a href="#" class="open-send-message" data-sender="<?php echo e($companyDetail->company_id); ?>"><?php echo app('translator')->get('wy.send_message'); ?></a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row user-contacts">
                <div class="col-sm-4 col-md-4 address">
                    <h5><?php echo app('translator')->get("my.contact"); ?></h5>
                    <div class="clr"></div>
                    <ul>
                        <li>
                            <p><span><?php if(isset($companyDetail->townRelation)): ?><?php echo e($companyDetail->townRelation->name_rs); ?><?php endif; ?></span></p>
                            <p><?php echo e($companyDetail->address); ?></p>
                            <p><span><?php echo e($companyDetail->phone); ?></span></p>
                        </li>
                    </ul>
                    <ul>
                        <li>
                            <p><span><?php if(isset($companyDetail->town2Relation)): ?><?php echo e($companyDetail->town2Relation->name_rs); ?><?php endif; ?></span></p>
                            <p><?php echo e($companyDetail->address_2); ?></p>
                            <p><span><?php echo e($companyDetail->phone_2); ?></span></p>
                        </li>
                    </ul>
                    <ul>
                        <li>
                            <p><span><?php if(isset($companyDetail->town3Relation)): ?><?php echo e($companyDetail->town3Relation->name_rs); ?><?php endif; ?></span></p>
                            <p><?php echo e($companyDetail->address_3); ?></p>
                            <p><span><?php echo e($companyDetail->phone_3); ?></span></p>
                        </li>
                    </ul>
                </div>
                <div class="col-md-8 col-md-8 text">
                    <h2><span><?php echo app('translator')->get('wy.info'); ?></span></h2>
                    <p><?php echo e($companyDetail->description); ?></p>
                </div>
            </div>
            <div class="row user-map">
                <div class="col-xs-12">
                    <div id="map"></div>
                </div>
            </div>
            <div class="row user-data-list">
                <div class="col-sm-4 col-md-4 user-data-list-box">
                    <h5><?php echo app('translator')->get("my.website"); ?></h5>
                    <ul>
                        <li><a href="https://<?php echo e($companyDetail->website); ?>" target="_blank"><?php echo e($companyDetail->website); ?></a></li>
                    </ul>
                </div>
                <div class="col-sm-4 col-md-4 social user-data-list-box">
                    <h5><?php echo app('translator')->get("my.social_networks"); ?></h5>
                    <ul>
                        <li>
                            <?php if(isset($companyDetail->facebook) && $companyDetail->facebook != ""): ?>
                                <a href="https://<?php echo e($companyDetail->facebook); ?>" target="_blank">
                                    <img src="/img/template-icons/facebook.png" alt="Facebook">
                                </a>
                            <?php endif; ?>
                        </li>
                        <li>
                            <?php if(isset($companyDetail->twitter) && $companyDetail->twitter != ""): ?>
                                <a href="https://<?php echo e($companyDetail->twitter); ?>" target="_blank">
                                    <img src="/img/template-icons/twitter.png" alt="Twitter">
                                </a>
                            <?php endif; ?>
                        </li>
                    </ul>
                </div>
                <div class="col-sm-4 col-md-4 user-data-list-box">
                    <h5><?php echo app('translator')->get("my.working_hours"); ?></h5>
                    <?php if(empty($companyDetail->hours)): ?>
                        <p>Ne postoji informacija o radnom vremenu</p>
                    <?php else: ?>
                        <ul>
                        <?php $__currentLoopData = $companyDetail->hours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $working_from = '';
                                $working_to = '';
                                if(!empty($hour->working_from)) {
                                   $working_from = explode(':',$hour->working_from);
                                   $working_from = $working_from[0] .':'. $working_from[1];
                                }
                                if(!empty($hour->working_to)) {
                                    $working_to = explode(':',$hour->working_to);
                                    $working_to = $working_to[0] .':'. $working_to[1];
                                }
                            ?>
                             <li>
                                <p><?php echo app('translator')->get($weekdays[$hour->weekday]); ?></p>
                                <span><?php echo e($working_from); ?> - <?php echo e($working_to); ?></span>
                            </li>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
                <div class="row user-media-head">
                    <div class="col-xs-12">
                        <h3 class="pull-left" ><?php echo app('translator')->get("my.gallery"); ?></h3>
                        
                        <?php if(Auth::check() && $companyDetail->company_id == \Illuminate\Support\Facades\Auth::user()->id): ?>
                            <a class="pull-right user-media-add" href="#" id="add-images-click"><?php echo app('translator')->get('wy.add_image'); ?></a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php if(count($optionalImages) > 0): ?>
                <div class="row user-media-body">
                    <?php $__currentLoopData = $optionalImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xs-12 col-sm-3 col-md-3 user-media-body-image">
                            <?php if(Auth::check() && $companyDetail->company_id == \Illuminate\Support\Facades\Auth::user()->id): ?>
                                <div class="user-media-image">
                                    <img src="/<?php echo e($image->user_image); ?>" class="remove-image">
                                    <span class="remove-image-span" data-imageid="<?php echo e($image->id); ?>"></span>
                                </div>
                            <?php else: ?>
                                <div class="user-media-image">
                                    <a href="/<?php echo e($image->user_image); ?>" data-lightbox="main-set" data-title="">
                                        <img src="/<?php echo e($image->user_image); ?>">
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
            <div class="clr"></div>
            <?php if(isset($companyDetail->youtube_1) || isset($companyDetail->youtube_2)): ?>
                <div class="row user-media-head">
                    <div class="col-xs-12">
                        <h3 class="pull-left" >Video</h3>
                        
                        
                    </div>
                </div>
                <div class="row user-media-body">
                    <div class="col-xs-12 col-sm-6 col-md-6 user-media-body-image">
                        <?php if(isset($companyDetail->youtube_1)): ?>
                            <iframe width="100%" height="255" src="<?php echo e($companyDetail->youtube_1); ?>" frameborder="0" allowfullscreen></iframe>
                        <?php endif; ?>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-6 user-media-body-image">
                        <?php if(isset($companyDetail->youtube_1)): ?>
                            <iframe width="100%" height="255" src="<?php echo e($companyDetail->youtube_2); ?>" frameborder="0" allowfullscreen></iframe>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
            
                
                    
                    
                    
                        
                    
                    
                        
                            
                        
                        
                            
                            
                            
                        
                        
                            
                                
                                
                                
                                
                                
                            
                        
                    
                    
                        
                            
                        
                        
                            
                            
                            


                        
                        
                            
                                
                                
                                
                                
                                
                            
                        
                    
                    
                        
                            
                        
                        
                            
                            
                            
                        
                        
                            
                                
                                
                                
                                
                                
                            
                        
                    
                
            
            
                
                    
                        
                        
                        
                        
                        
                    
                
            
        </div>
    </section>
    <div class="popup-overlay" style="display: none;"></div>
    <div class="popup-wrapp" id="add-images-pop">
        <div class="close close-popup"><img src="/img/template-icons/close.png" alt=""/></div>
        <div class="popup-body">
            <div class="row">
                <div class="col-xs-12">
                    <div class="register-body">
                        <div class="form-group">
                            <form method="post" enctype="multipart/form-data" action="/<?php echo e(\Illuminate\Support\Facades\App::getLocale()); ?>/profil-kompanije/izmena-slika">
                                <?php echo e(csrf_field()); ?>

                                <label><?php echo app('translator')->get('my.change_image'); ?></label><br>
                                <input type="file" name="userImage" onchange="this.form.submit()">
                                <?php if(isset($companyDetail->user->user_image)): ?>
                                    <img src="/<?php echo e($companyDetail->user->user_image); ?>"
                                         style="margin: -45px 0 0 50px;">
                                <?php endif; ?>
                            </form>
                        </div>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <div class="form-group">
                            <form method="post" enctype="multipart/form-data" action="/<?php echo e(\Illuminate\Support\Facades\App::getLocale()); ?>/profil-kompanije/izmena-slika">
                                <?php echo e(csrf_field()); ?>

                                <label><?php echo app('translator')->get('my.add_images'); ?></label><br>
                                <input type="file" name="optionalImage" onchange="this.form.submit()">
                            </form>
                        </div>
                        <div class="register-note">
                            <p></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script async defer
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBirnZ7HNdfWrk3VePYb6ottoRPwgrtQrQ">
    </script>
    <script>
        var uluru = {lat: Number(<?php echo e(($companyDetail->first_lat + $companyDetail->second_lat + $companyDetail->third_lat) / 3); ?>),
                    lng: Number(<?php echo e(($companyDetail->first_lng + $companyDetail->second_lng + $companyDetail->third_lng) / 3); ?>)};

        var popup = '<div class="popup-custom-content"><h1><?php echo e($companyDetail->company_name); ?></h1>';
        popup += '<p><?php if(isset($companyDetail->categoryRelation)): ?><?php echo e($companyDetail->categoryRelation->name_rs); ?><?php endif; ?></p>';
        popup += '<ul><li><p><span>Adresa</span></p><p><?php echo e($companyDetail->address); ?></p><p><?php if(isset($companyDetail->townRelation)): ?><?php echo e($companyDetail->townRelation->name_rs); ?><?php endif; ?></p>';
        popup += '<p><span>Telefon</span><?php echo e($companyDetail->phone); ?></p></div>';

        var locations = [];
        locations.push([popup, "<?php echo e($companyDetail->first_lat); ?>", "<?php echo e($companyDetail->first_lng); ?>"]);
        locations.push([popup, "<?php echo e($companyDetail->second_lat); ?>", "<?php echo e($companyDetail->second_lng); ?>"]);
        locations.push([popup, "<?php echo e($companyDetail->third_lat); ?>", "<?php echo e($companyDetail->third_lng); ?>"]);

        setTimeout(function(){initMap();}, 500);

        function initMap() {
            map = new google.maps.Map(document.getElementById('map'), {
                center: uluru,
                scrollwheel: false
            });

            var bounds = new google.maps.LatLngBounds();
            var infowindow = new google.maps.InfoWindow();
            var marker, i;

            for (i = 0; i < locations.length; i++) {
                marker = new google.maps.Marker({
                    position: new google.maps.LatLng(locations[i][1], locations[i][2]),
                    map: map
                });

                bounds.extend(marker.position);

                google.maps.event.addListener(marker, 'click', (function(marker, i) {
                    return function() {
                        infowindow.setContent(locations[i][0]);
                        infowindow.open(map, marker);
                    }
                })(marker, i));
            }

            map.fitBounds(bounds);

//            var listener = google.maps.event.addListener(map, "idle", function () {
//                map.setZoom(12);
//                google.maps.event.removeListener(listener);
//            });
        }
    </script>
    <?php if(Session::has('uploaded_image')): ?>
        <script>
            setTimeout(function(){$('#add-images-click').click();}, 500);
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>