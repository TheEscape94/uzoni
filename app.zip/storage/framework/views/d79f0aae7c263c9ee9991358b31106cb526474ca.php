<?php $__env->startSection('content'); ?>
    <section class="pull-left full-width register">
        <div class="full-width register-background"></div>
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="register-head">
                        <span class="register-dec"></span>
                        <div class="clr"></div>
                        <?php if(\Illuminate\Support\Facades\App::getLocale() == 'en'): ?>
                            <p>Profile <br/><span>Settings</span></p>
                        <?php else: ?>
                            <p>Podesavanje <br/><span>Profila</span></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12">
                    <div class="register-body">
                        <form action="<?php echo e(url('/update-profile')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <h2><?php echo app('translator')->get('my.basic_info'); ?>:</h2>
                            <div class="form-group">
                                <input type="text" name="company_name" placeholder="<?php echo app('translator')->get('my.company_name'); ?>" value="<?php echo e($companyDetail->company_name); ?>">
                            </div>
                            <div class="form-group">
                                <select name="category">
                                    <option selected disabled><?php echo app('translator')->get('my.category'); ?></option>
                                    <?php $__currentLoopData = $mainCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(\Illuminate\Support\Facades\App::getLocale() == 'en'): ?>
                                            <optgroup label="<?php echo e($cat->name_en); ?>">
                                        <?php else: ?>
                                            <optgroup label="<?php echo e($cat->name_rs); ?>">
                                        <?php endif; ?>
                                        <?php $__currentLoopData = $cat->subGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($subCat->id); ?>" <?php echo e($subCat->id == $companyDetail->category ? "selected" : ""); ?>>
                                                <?php if(\Illuminate\Support\Facades\App::getLocale() == 'en'): ?>
                                                    <?php echo e($subCat->name_en); ?>

                                                <?php else: ?>
                                                    <?php echo e($subCat->name_rs); ?>

                                                <?php endif; ?>
                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </optgroup>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <select class="optional-choose" name="category_2">
                                    <option selected disabled><?php echo app('translator')->get('my.category'); ?> 2</option>
                                    <?php if(isset($mainCategories) && !empty($mainCategories)): ?>
                                        <?php $__currentLoopData = $mainCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(\Illuminate\Support\Facades\App::getLocale() == 'en'): ?>
                                                <optgroup label="<?php echo e($cat->name_en); ?>">
                                            <?php else: ?>
                                                <optgroup label="<?php echo e($cat->name_rs); ?>">
                                            <?php endif; ?>

                                            <?php $__currentLoopData = $cat->subGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($subCat->id); ?>" <?php echo e($subCat->id == $companyDetail->category_2 ? "selected" : ""); ?>>
                                                    <?php if(\Illuminate\Support\Facades\App::getLocale() == 'en'): ?>
                                                        <?php echo e($subCat->name_en); ?>

                                                    <?php else: ?>
                                                        <?php echo e($subCat->name_rs); ?>

                                                    <?php endif; ?>
                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </optgroup>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <select class="optional-choose" name="category_3">
                                    <option selected disabled><?php echo app('translator')->get('my.category'); ?> 3</option>
                                    <?php $__currentLoopData = $mainCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(\Illuminate\Support\Facades\App::getLocale() == 'en'): ?>
                                            <optgroup label="<?php echo e($cat->name_en); ?>">
                                        <?php else: ?>
                                            <optgroup label="<?php echo e($cat->name_rs); ?>">
                                        <?php endif; ?>
                                        <?php $__currentLoopData = $cat->subGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($subCat->id); ?>" <?php echo e($subCat->id == $companyDetail->category_3 ? "selected" : ""); ?>>
                                                <?php if(\Illuminate\Support\Facades\App::getLocale() == 'en'): ?>
                                                    <?php echo e($subCat->name_en); ?>

                                                <?php else: ?>
                                                    <?php echo e($subCat->name_rs); ?>

                                                <?php endif; ?>
                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </optgroup>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
<!--                            new elements-->
                            <div class="form-group">
                                <h2 class="h2-line"><span>Adresa 1</span></h2>
                            </div>
                            <div class="form-group half pull-right">
                                <input type="text" name="address" class="autocomplete_first" placeholder="<?php echo app('translator')->get('wy.address'); ?> 1" value="<?php echo e($companyDetail->address); ?>">
                                <input type="hidden" id="firstLat" name="first_lat" value="<?php echo e($companyDetail->first_lat ? $companyDetail->first_lat : 0); ?>">
                                <input type="hidden" id="firstLng" name="first_lng" value="<?php echo e($companyDetail->first_lng ? $companyDetail->first_lng : 0); ?>">
                            </div>
                            <div class="form-group half">
                                <select name="town">
                                    <option><?php echo app('translator')->get('my.town'); ?></option>
                                    <?php $__currentLoopData = $towns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $town): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($town->id); ?>" <?php echo e($town->id == $companyDetail->town ? "selected" : ""); ?>>
                                            <?php if(\Illuminate\Support\Facades\App::getLocale() == 'en'): ?>
                                                <?php echo e($town->name_en); ?>

                                            <?php else: ?>
                                                <?php echo e($town->name_rs); ?>

                                            <?php endif; ?>
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group half">
                                <input type="text" name="phone" placeholder="<?php echo app('translator')->get('wy.phones'); ?>" value="<?php echo e($companyDetail->phone); ?>">
                            </div>
                            <div class="form-group half pull-right">
                                <input type="text" name="phone" placeholder="<?php echo app('translator')->get('wy.phones'); ?> -opciono" value="<?php echo e($companyDetail->phone); ?>">
                            </div>
                            
                            <div class="form-group">
                                <h2 class="h2-line"><span>Adresa 2</span></h2>
                                    <img class="open-more set-2" src="/img/template-icons/dropdown-selector.png" />
                            </div>
                            <div class="form-group info-set-2">
                                <div class="form-group half">
                                <select name="town_2">
                                    <option><?php echo app('translator')->get('my.town'); ?> 2</option>
                                    <?php $__currentLoopData = $towns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $town): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($town->id); ?>" <?php echo e($town->id == $companyDetail->town_2 ? "selected" : ""); ?>>
                                            <?php if(\Illuminate\Support\Facades\App::getLocale() == 'en'): ?>
                                                <?php echo e($town->name_en); ?>

                                            <?php else: ?>
                                                <?php echo e($town->name_rs); ?>

                                            <?php endif; ?>
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group half pull-right">
                                <input type="text" name="address_2" class="autocomplete_second" placeholder="<?php echo app('translator')->get('wy.address'); ?> 2" value="<?php echo e($companyDetail->address_2); ?>">
                                <input type="hidden" id="secondLat" name="second_lat" value="<?php echo e($companyDetail->second_lat ? $companyDetail->second_lat : 0); ?>">
                                <input type="hidden" id="secondLng" name="second_lng" value="<?php echo e($companyDetail->second_lng ? $companyDetail->second_lng : 0); ?>">
                            </div>
                            <div class="form-group">
                                <input type="text" name="phone_2" placeholder="<?php echo app('translator')->get('wy.phones'); ?> 2" value="<?php echo e($companyDetail->phone_2); ?>">
                            </div>
                            </div>
                            <div class="form-group">
                                <h2 class="h2-line"><span>Adresa 3</span></h2>
                                 <img class="open-more set-3" src="/img/template-icons/dropdown-selector.png" />
                            </div>
                            <div class="form-group info-set-3">
                                <div class="form-group half">
                                <select name="town_3">
                                    <option><?php echo app('translator')->get('my.town'); ?> 3</option>
                                    <?php $__currentLoopData = $towns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $town): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($town->id); ?>" <?php echo e($town->id == $companyDetail->town_3 ? "selected" : ""); ?>>
                                            <?php if(\Illuminate\Support\Facades\App::getLocale() == 'en'): ?>
                                                <?php echo e($town->name_en); ?>

                                            <?php else: ?>
                                                <?php echo e($town->name_rs); ?>

                                            <?php endif; ?>
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group half pull-right">
                                <input type="text" name="address_3" class="autocomplete_third" placeholder="<?php echo app('translator')->get('wy.address'); ?> 3" value="<?php echo e($companyDetail->address_3); ?>">
                                <input type="hidden" id="thirdLat" name="third_lat" value="<?php echo e($companyDetail->third_lat ? $companyDetail->third_lat : 0); ?>">
                                <input type="hidden" id="thirdLng" name="third_lng" value="<?php echo e($companyDetail->third_lng ? $companyDetail->third_lng : 0); ?>">
                            </div>
                            <div class="form-group">
                                <input type="text" name="phone_3" placeholder="<?php echo app('translator')->get('wy.phones'); ?> 3" value="<?php echo e($companyDetail->phone_2); ?>">
                            </div>
                            </div>
                            <?php if(count($companyDetail->hours) == 0): ?>
                                <div class="form-group results-message">
                                    <a class="jcf-button" style="border-radius:0px" id="open-working-hours-popup" href="#">Unesite radno vreme</a>
                                </div>
                            <?php else: ?>
                                <div class="clearfix"></div>
                                <div class="col-sm-12 col-md-12 user-data-list" >
                                    <h5><?php echo app('translator')->get("my.working_hours"); ?></h5>
                                    <ul>
                                    <?php $__currentLoopData = $companyDetail->hours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                        <?php 
                                            $working_from = '';
                                            $working_to = '';
                                            if(!empty($hour->working_from)) {
                                               $working_from = explode(':',$hour->working_from);
                                               $working_from = $working_from[0] .':'. $working_from[1];  
                                            }
                                            if(!empty($hour->working_to)) {
                                                $working_to = explode(':',$hour->working_to);
                                                $working_to = $working_to[0] .':'. $working_to[1];  
                                            }
                                        ?>
                                         <li syle="margin-bottom:15px;">
                                            <p><?php echo app('translator')->get($weekdays[$hour->weekday]); ?></p>
                                            <span style="width: 100%;"><input class="workday-from" type="text" id="<?php echo e($hour->weekday); ?>-from" " name="<?php echo e($hour->weekday); ?>-from" value="<?php echo e($working_from); ?>" /> - <input type="text" class="workday-to" value="<?php echo e($working_to); ?>"  id="<?php echo e($hour->weekday); ?>-to" " name="<?php echo e($hour->weekday); ?>-to" /></span>
                                        </li>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                                
                            <?php endif; ?>
                            <div class="clearfix"></div>
                            
                            <div style="margin-bottom: 30px">
                                <label for="description" style="margin-bottom: 13px; color: #2d2d2d; font-size: 16px;"><?php echo app('translator')->get("my.description"); ?></label>
                                <textarea name="description" rows="7" cols="72"><?php echo e($companyDetail->description); ?></textarea>
                            </div>
<!--                            social-->
                            <div class="form-group half">
                                <input type="text" name="website" placeholder="Website" value="<?php echo e($companyDetail->website); ?>">
                            </div>
                            <div class="form-group half pull-right">
                                <input type="text" name="facebook" placeholder="Facebook" value="<?php echo e($companyDetail->facebook); ?>">
                            </div>
                            <div class="form-group half">
                                <input type="text" name="twitter" placeholder="Twitter" value="<?php echo e($companyDetail->twitter); ?>">
                            </div>
                            <div class="form-group half pull-right">
                                <input type="text" name="google+" placeholder="Google +" value="">
                            </div>
                            
                            <div class="form-group">
                                <input type="text" name="youtube_1" placeholder="Youtube video 1" >
                            </div>
                            <div class="form-group">
                                <input type="text" name="youtube_2" placeholder="Youtube video 2" >
                            </div>
                            <div class="form-group half">
                                
                                <input class="" type="checkbox" name="nonstop" id="addNonstop" value="1" <?php if($companyDetail->nonstop): ?> checked <?php endif; ?>>
                                <label for="nonstop"><?php echo app('translator')->get('wy.247'); ?></label>
                            </div>
                            <div class="form-group half">
                                <input type="checkbox" name="home_delivery" id="addHomeDelivery" value="1" <?php if($companyDetail->home_delivery): ?> checked <?php endif; ?>>
                                
                                 <label for="home_delivery"><?php echo app('translator')->get('wy.home_delivery'); ?></label>
                            </div>
                            
                                
                                
                                <input type="hidden" name="online_banking" id="addOnlineBanking" value="0">
                            

                            <div class="form-group">
                                <input type="submit" name="register" value="Azuriraj profil">
                            </div>
                            <div class="register-note">
                                <p></p>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="popup-wrapp" id="working-hours-popup">
        <div class="close close-popup"><img src="/img/template-icons/close.png" alt="" /></div>
        <div class="popup-body">
            <div class="row text-center working-hours">
                <div class="col-md-12" style="margin-bottom: 15px;">
                    <h3><?php echo app('translator')->get('wy.working_hours'); ?></h3><br><Br>
                </div>
                <div class="alert alert-danger" style="display: none;">
                    <strong>Error!</strong>
                </div>
                <form action="#" method="post" id="working-hours-form">
                    <section class="form-group working-hours-head clearfix">
                        <div class="col-md-1">
                            <p>&nbsp;</p>
                        </div>
                        <div class="checkbox-holder">
                            <input type="checkbox" class="mon" id="mon" value="1" />
                            <br>
                            <labl for="mon"><?php echo app('translator')->get('wy.monday'); ?></label>
                        </div>
                        <div class="checkbox-holder">
                            <input type="checkbox" name="tue" id="tue" value="1" />
                            <br>
                            <labl for="tue"><?php echo app('translator')->get('wy.tuesday'); ?></label>
                        </div>
                        <div class="checkbox-holder">
                            <input type="checkbox" name="wed" id="wed" value="1" />
                            <br>
                            <labl for="wed"><?php echo app('translator')->get('wy.wednesday'); ?></label>
                        </div>
                        <div class="checkbox-holder">
                            <input type="checkbox" name="thu" id="thu" value="1" />
                            <br>
                            <labl for="thu"><?php echo app('translator')->get('wy.thursday'); ?></label>
                        </div>
                        <div class="checkbox-holder">
                            <input type="checkbox" name="fri" id="fri" value="1" />
                            <br>
                            <labl for="fri"><?php echo app('translator')->get('wy.friday'); ?></label>
                        </div>
                        <div class="checkbox-holder">
                            <input type="checkbox" name="sat" id="sat" value="1" />
                            <br>
                            <labl for="sat"><?php echo app('translator')->get('wy.saturday'); ?></label>
                        </div>
                        <div class="checkbox-holder">
                            <input type="checkbox" name="sun" id="sun" value="1" />
                            <br>
                            <labl for="sun"><?php echo app('translator')->get('wy.sunday'); ?></label>
                        </div>
                        <div style="clear: both"></div>
                    </section>
                    <section class="form-group working-hours-input clearfix">
                        <div class="col-md-1 hours-head">
                            <p><?php echo app('translator')->get('wy.from_to'); ?></p>
                        </div>
                        <input type="text" name="mon-from" class="mon-from" id="mon-from" value="" />
                        <input type="text" name="tue-from" id="tue-from" />
                        <input type="text" name="wed-from" id="wed-from" />
                        <input type="text" name="thu-from" id="thu-from" />
                        <input type="text" name="fri-from" id="fri-from" />
                        <input type="text" name="sat-from" id="sat-from" />
                        <input type="text" name="sun-from" id="sun-from" />
                    </section>
                    <section class="form-group working-hours-input clearfix">
                        <div class="col-md-1 hours-head">
                            <p><?php echo app('translator')->get('wy.to_from'); ?></p>
                        </div>
                        <input type="text" name="mon-to" id="mon-to" value="" />
                        <input type="text" name="tue-to" id="tue-to" />
                        <input type="text" name="wed-to" id="wed-to" />
                        <input type="text" name="thu-to" id="thu-to" />
                        <input type="text" name="fri-to" id="fri-to" />
                        <input type="text" name="sat-to" id="sat-to" />
                        <input type="text" name="sun-to" id="sun-to" />
                    </section>
                    <div class="pull-right form-group bid-choose">
                        <span class="accept"><input type="button" name="save-working-hours" id="save-working-hours" value="<?php echo app('translator')->get('wy.save_hours'); ?>" /></span>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <script>
        function initAutocomplete() {
            autocomplete_first = new google.maps.places.Autocomplete(
                    (document.getElementsByClassName('autocomplete_first')[0]),
                    {types: ['geocode']});

            autocomplete_first.addListener('place_changed', fillInFirst);


            autocomplete_second = new google.maps.places.Autocomplete(
                    (document.getElementsByClassName('autocomplete_second')[0]),
                    {types: ['geocode']});

            autocomplete_second.addListener('place_changed', fillInSecond);


            autocomplete_third = new google.maps.places.Autocomplete(
                    (document.getElementsByClassName('autocomplete_third')[0]),
                    {types: ['geocode']});

            autocomplete_third.addListener('place_changed', fillInThird);
        }

        function fillInFirst() {
            // Get the place details from the autocomplete object.
            var place = autocomplete_first.getPlace();

            document.getElementById("firstLat").value = place.geometry.location.lat();
            document.getElementById("firstLng").value = place.geometry.location.lng();
        }

        function fillInSecond() {
            // Get the place details from the autocomplete object.
            var place = autocomplete_second.getPlace();
            console.log(place);
            document.getElementById("secondLat").value = place.geometry.location.lat();
            document.getElementById("secondLng").value = place.geometry.location.lng();
        }

        function fillInThird() {
            // Get the place details from the autocomplete object.
            var place = autocomplete_third.getPlace();

            document.getElementById("thirdLat").value = place.geometry.location.lat();
            document.getElementById("thirdLng").value = place.geometry.location.lng();
        }

    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCDaJFvQ0HSUcobxJ09pJo_apVccpmqMiU&libraries=places&callback=initAutocomplete"
            async defer></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>