

<?php $__env->startSection('content'); ?>
    <section class="pull-left full-width register">
        <div class="full-width register-background"></div>
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="register-head">
                        <span class="register-dec"></span>
                        <div class="clr"></div>
                        <p>Registracija <br/><span>POSLODAVCA</span></p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12">
                    <div class="register-body">
                        <form>
                            <h2>Osnovni podaci:</h2>
                            <div class="form-group">
                                <input type="text" name="" placeholder="Naziv firme">
                            </div>
                            <div class="form-group">
                                <select>
                                    <option>Kategorija/podkategorija</option>
                                </select>
                            </div>
                            <div class="form-group half">
                                <input type="text" name="" placeholder="Ime">
                            </div>
                            <div class="pull-right form-group half">
                                <input type="text" name="" placeholder="Prezime">
                            </div>
                            <div class="form-group half">
                                <input type="text" name="" placeholder="Telefon">
                            </div>
                            <div class="pull-right form-group half">
                                <input type="text" name="" placeholder="Fax(opciono)">
                            </div>
                            <div class="form-group">
                                <input type="text" name="" placeholder="Adresa">
                            </div>
                            <div class="form-group two-third">
                                <select>
                                    <option>Grad</option>
                                </select>
                            </div>
                            <div class="pull-right form-group one-third">
                                <input type="text" name="" placeholder="Postanski broj">
                            </div>
                            <h2>Pristupni podaci:</h2>
                            <div class="form-group">
                                <input type="text" name="" placeholder="Email">
                            </div>
                            <div class="form-group half">
                                <input type="password" name="" placeholder="Sifra">
                            </div>
                            <div class="pull-right form-group half">
                                <input type="password" name="" placeholder="Ponovi sifru">
                            </div>
                            <div class="form-group">
                                <input type="submit" name="" value="Registruj se">
                            </div>
                            <div class="register-note">
                                <p>Klikom na dugme <span>"Registruj se"</span> potvrđuješ saglasnost sa uslovima korišćenja.</p>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>