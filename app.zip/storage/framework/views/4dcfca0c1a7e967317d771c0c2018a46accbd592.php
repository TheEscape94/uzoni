<?php $__env->startSection('content'); ?>
    <section class="pull-left full-width main-search">
        <div class="container">
            <div class="row">
                <div class="col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3">
                    <form class="pull-left full-width">
                        <input type="submit" name="" value=" " />
                        <input type="text" name="" placeholder="Pretrazi..." />
                        <select>
                            <option>Novi Sad</option>
                            <option>Nis</option>
                        </select>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <div class="clr"></div>
    <section class="pull-left full-width categories">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 categories-head">
                    <div class="categories-star"><img src="img/user/star-rated.png" /></div>
                    <h1>Popularne kategorije</h1>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-3 col-md-3 categories-box">
                    <a href="#">
                        <h4 class="categories-title">Vodoinstalater</h4>
                        <div class="clr"></div>
                        <div class="categories-img">
                            <img src="img/category1.jpg" alt="" />
                        </div>
                    </a>
                </div>
                <div class="col-xs-12 col-sm-3 col-md-3 categories-box">
                    <a href="#">
                        <h4 class="categories-title">Automehanicar</h4>
                        <div class="clr"></div>
                        <div class="categories-img">
                            <img src="img/category2.jpg" alt="" />
                        </div>
                    </a>
                </div>
                <div class="col-xs-12 col-sm-3 col-md-3 categories-box">
                    <a href="#">
                        <h4 class="categories-title">Nekretnine</h4>
                        <div class="clr"></div>
                        <div class="categories-img">
                            <img src="img/category3.jpg" alt="" />
                        </div>
                    </a>
                </div>
                <div class="col-xs-12 col-sm-3 col-md-3 categories-box">
                    <a href="#">
                        <h4 class="categories-title">Auto</h4>
                        <div class="clr"></div>
                        <div class="categories-img">
                            <img src="img/category1.jpg" alt="" />
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>