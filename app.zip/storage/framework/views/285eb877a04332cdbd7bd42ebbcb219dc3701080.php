<?php $__env->startSection('content'); ?>
    <section class="pull-left full-width user-profile">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 user-head">
                    <div class="user-image">
                        <img src="/img/user/user-default.png" alt="">
                    </div>
                    <div class="user-data">
                        <p>Petar Petrovic</p>
                        <div class="clr"></div>
                        <span>Korisnik</span>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-7 user-selling">
                    <h4>Lista kupovine</h4>
                    <ul>
                        <li class="date">Danas</li>
                        <li class="hour">15:43</li>
                        <li class="name">Vodoinstalater - <span>Ime Prezime</span></li>
                    </ul>
                    <ul>
                        <li class="date">28.11.2016</li>
                        <li class="hour">08:58</li>
                        <li class="name">Bravar - <span>Ime Prezime</span></li>
                    </ul>
                    <ul>
                        <li class="date">07.08.2016</li>
                        <li class="hour">15:43</li>
                        <li class="name">Servis mobilnih telefona - <span>Ime Prezime</span></li>
                    </ul>
                    <ul>
                        <li class="date">14.03.2016</li>
                        <li class="hour">11:29</li>
                        <li class="name">Elektricar - <span>Ime Prezime</span></li>
                    </ul>
                    <ul>
                        <li class="date">14.03.2016</li>
                        <li class="hour">11:29</li>
                        <li class="name">Elektricar - <span>Ime Prezime</span></li>
                    </ul>
                </div>
                <div class="col-xs-12 col-sm-5 user-buying">
                    <a href="#" class="user-shopping">Ponovi Kupovinu</a>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>