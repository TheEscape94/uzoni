<?php $__env->startSection('content'); ?>
<div class="container packages-page">
    <div class="row">
        <div class="col-lg-12 text-center">
            <h1>Paketi</h1>
            <h2>Odaberite jedan od nasa 3 paketa:</h2>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-4">
            <div class="data-column">
                <h3 class="silver">
                    Silver
                    <span>Paket</span>
                </h3>
                <hr>
                <div class="elements">
                    <p class="strong">Profili</p>
                    <br>
                    <p>Logo</p>
                    <p>Adresa</p>
                    <p>Email</p>
                    <p>Broj telefona</p>
                    <p>Link ka vasem web sajtu</p>
                </div>
                <p class="locations">3 lokacije</p>
                <hr>
                <p class="price">1000 rsd</p>
                <hr>
                <a href="" class="grey">Kupi</a>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="data-column">
                <h3 class="gold">
                    Gold
                    <span>Paket</span>
                </h3>
                <hr>
                <div class="elements">
                    <p class="strong">Profili</p>
                    <br>
                    <p>Logo</p>
                    <p>Adresa</p>
                    <p>Email</p>
                    <p>Broj telefona</p>
                    <p>Link ka vasem web sajtu</p>
                    <p>Linkovi vasih drustvenih mreza</p>
                    <p>Isticanje u podkategoriji</p>
                </div>
                <p class="locations">5 lokacija</p>
                <hr>
                <p class="price">2000 rsd</p>
                <hr>
                <a href="" class="gold">Kupi</a>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="data-column">
                <h3 class="platinum">
                    Platinum
                    <span>Paket</span>
                </h3>
                <hr>
                <div class="elements">
                    <p class="strong">Profili</p>
                    <br>
                    <p>Logo</p>
                    <p>Adresa</p>
                    <p>Email</p>
                    <p>Broj telefona</p>
                    <p>Link ka vasem web sajtu</p>
                    <p>Linkovi vasih drustvenih mreza</p>
                    <p>Isticanje u podkategoriji</p>
                    <p>Isticanje u kategoriji</p>
                    <p>Isticanje u gradu</p>
                    <p>Isticanje na mapi</p>
                </div>
                <p class="locations">7 lokacije</p>
                <hr>
                <p class="price">5000 rsd</p>
                <hr>
                <a href="">Kupi</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>