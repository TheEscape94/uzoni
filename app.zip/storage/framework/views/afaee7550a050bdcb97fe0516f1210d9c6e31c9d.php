

<?php $__env->startSection('content'); ?>
    <section class="pull-left full-width search-map">
        <div class="full-width pull-left">
            <div id="map_canvas"></div>
        </div>
    </section>
    <div class="clr"></div>
    <section class="pull-left full-width filters">
        <div class="container">
            <form>
                <div class="row">
                    <div class="col-sm-8 filters-left">
                        <div class="form-group">
                            <select>
                                <option>Vodinstalater</option>
                                <option>Elektricar</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-sm-4 filters-right">
                        <div class="form-group">
                            <span class="pull-right" id="filters-trigger">Filteri</span>
                            <select class="pull-right">
                                <option>Novi Sad</option>
                                <option>Nis</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row filters-expand">
                    <div class="col-sm-8 filters-expand-left">
                        <div class="form-group">
                            <div class="form-group-checkbox">
                                <input type="checkbox" id="chk1" />
                                <label for="chk1">Po blizini</label>
                            </div>
                            <div class="form-group-checkbox">
                                <input type="checkbox" id="chk2" />
                                <label for="chk2">Najpopularniji</label>
                            </div>
                            <div class="form-group-checkbox">
                                <input type="checkbox" id="chk3" />
                                <label for="chk3">Po oceni</label>
                            </div>
                            <div class="clr"></div>
                            <div class="form-group-checkbox">
                                <input type="checkbox" id="chk4" />
                                <label for="chk4">24h Radno vreme</label>
                            </div>
                            <div class="form-group-checkbox">
                                <input type="checkbox" id="chk5" />
                                <label for="chk5">Dolazak na kucnu adresu</label>
                            </div>
                            <div class="form-group-checkbox">
                                <input type="checkbox" id="chk6" />
                                <label for="chk6">Lojalnost musterija</label>
                            </div>
                            <div class="form-group-checkbox">
                                <input type="checkbox" id="chk7" />
                                <label for="chk7">Online placanja</label>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4 filters-expand-right">
                        <div class="form-group">
                            <input type="range" value="30" min="0" max="100" list="filters-range" data-jcf='{"orientation": "horizontal", "range": "min"}'>
                            <div class="clr"></div>
                            <div class="pull-left">0m</div>
                            <div class="pull-right">1km</div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>
    <div class="clr"></div>
    <section class="full-width pull-left results">
        <div class="results-box results-type-one">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="user-image">
                            <img src="/img/user/user-default.png"  alt="" />
                            <div class="user-level"><img src="/img/user/level-gold.png"  alt="" /></div>
                        </div>
                        <div class="results-user-data">
                            <h4>Petar Petrovic</h4>
                            <div class="clr"></div>
                            <div class="rate">
                                <ul>
                                    <li class="rated"></li>
                                    <li class="rated"></li>
                                    <li class="rated"></li>
                                    <li class="rated"></li>
                                    <li class=""></li>
                                </ul>
                            </div>
                            <div class="clr"></div>
                            <p class="results-job">Vodoinstalater</p>
                        </div>
                        <div class="results-user">
                            <ul class="results-user-list">
                                <li><img src="/img/user/time-icon.jpg" alt="" /></li>
                                <li><img src="/img/user/quality-icon.jpg" alt="" /></li>
                                <li><img src="/img/user/delivery-icon.jpg" alt="" /></li>
                                <li><img src="/img/user/pay-icon.png" alt="" /></li>
                            </ul>
                            <p class="results-user-active">Otvoreno</p>
                            <div class="clr"></div>
                            <span class="results-user-range">700m</span>
                        </div>
                        <div class="results-contacts">
                            <div class="pull-left full-width results-address">
                                <div class="results-address-box">
                                    <div class="full-width pull-left results-address-icon"></div>
                                    <div class="clr"></div>
                                    <p>Narodnog Fronta 59,</p>
                                    <p>Novi Sad</p>
                                </div>
                                <div class="results-address-box">
                                    <div class="full-width pull-left results-address-icon phone"></div>
                                    <div class="clr"></div>
                                    <p>064 1234567</p>
                                    <p>Novi Sad</p>
                                </div>
                            </div>
                            <div class="results-address-expand">
                                <div class="results-address-expand-box">
                                    <div class="results-address-box">
                                        <div class="full-width pull-left results-address-icon"></div>
                                        <div class="clr"></div>
                                        <p>Narodnog Fronta 59,</p>
                                        <p>Novi Sad</p>
                                    </div>
                                    <div class="results-address-box">
                                        <div class="full-width pull-left results-address-icon phone"></div>
                                        <div class="clr"></div>
                                        <p>064 1234567</p>
                                        <p>Novi Sad</p>
                                    </div>
                                </div>
                                <div class="results-address-expand-box">
                                    <div class="results-address-box">
                                        <div class="full-width pull-left results-address-icon"></div>
                                        <div class="clr"></div>
                                        <p>Narodnog Fronta 59,</p>
                                        <p>Novi Sad</p>
                                    </div>
                                    <div class="results-address-box">
                                        <div class="full-width pull-left results-address-icon phone"></div>
                                        <div class="clr"></div>
                                        <p>064 1234567</p>
                                        <p>Novi Sad</p>
                                    </div>
                                </div>
                            </div>
                            <div class="results-address-trigger"></div>
                        </div>
                        <div class="pull-right results-message">
                            <a href="#">Posalji poruku</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="results-box result-type-two">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="user-image">
                            <img src="/img/user/user-default-yellow.png"  alt="" />
                            <div class="full-width user-image-dec"></div>
                        </div>
                        <div class="results-user-data">
                            <h4>Petar Petrovic</h4>
                            <div class="clr"></div>
                            <div class="rate">
                                <ul>
                                    <li class="rated"></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                </ul>
                            </div>
                            <div class="clr"></div>
                            <p class="results-job">Vodoinstalater</p>
                        </div>
                        <div class="results-user">
                            <ul class="results-user-list">
                                <li><img src="/img/user/time-icon.jpg" alt="" /></li>
                                <li><img src="/img/user/quality-icon.jpg" alt="" /></li>
                            </ul>
                            <p class="results-user-deactive">Zatvoreno</p>
                            <div class="clr"></div>
                            <span class="results-user-range">1.7 km</span>
                        </div>
                        <div class="results-contacts">
                            <div class="pull-left full-width results-address">
                                <div class="results-address-box">
                                    <div class="full-width pull-left results-address-icon"></div>
                                    <div class="clr"></div>
                                    <p>Narodnog Fronta 59,</p>
                                    <p>Novi Sad</p>
                                </div>
                                <div class="results-address-box">
                                    <div class="full-width pull-left results-address-icon phone"></div>
                                    <div class="clr"></div>
                                    <p>064 1234567</p>
                                    <p>Novi Sad</p>
                                </div>
                            </div>
                            <div class="results-address-expand">
                                <div class="results-address-expand-box">
                                    <div class="results-address-box">
                                        <div class="full-width pull-left results-address-icon"></div>
                                        <div class="clr"></div>
                                        <p>Narodnog Fronta 59,</p>
                                        <p>Novi Sad</p>
                                    </div>
                                    <div class="results-address-box">
                                        <div class="full-width pull-left results-address-icon phone"></div>
                                        <div class="clr"></div>
                                        <p>064 1234567</p>
                                        <p>Novi Sad</p>
                                    </div>
                                </div>
                                <div class="results-address-expand-box">
                                    <div class="results-address-box">
                                        <div class="full-width pull-left results-address-icon"></div>
                                        <div class="clr"></div>
                                        <p>Narodnog Fronta 59,</p>
                                        <p>Novi Sad</p>
                                    </div>
                                    <div class="results-address-box">
                                        <div class="full-width pull-left results-address-icon phone"></div>
                                        <div class="clr"></div>
                                        <p>064 1234567</p>
                                        <p>Novi Sad</p>
                                    </div>
                                </div>
                            </div>
                            <div class="results-address-trigger"></div>
                        </div>
                        <div class="pull-right results-message">
                            <a href="#">Posalji poruku</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="results-box result-type-three">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="user-image">
                            <img src="/img/user/user-default.png"  alt="" />
                        </div>
                        <div class="results-user-data">
                            <h4>Petar Petrovic</h4>
                            <div class="clr"></div>
                            <div class="rate">
                                <ul>
                                    <li class="rated"></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li class=""></li>
                                </ul>
                            </div>
                            <div class="clr"></div>
                            <p class="results-job">Vodoinstalater</p>
                        </div>
                        <div class="results-user">
                            <ul class="results-user-list">
                            </ul>
                            <p class="results-user-active">Otvoreno</p>
                            <div class="clr"></div>
                            <span class="results-user-range">2.3 km</span>
                        </div>
                        <div class="results-contacts">
                            <div class="pull-left full-width results-address">
                                <div class="results-address-box">
                                    <div class="full-width pull-left results-address-icon"></div>
                                    <div class="clr"></div>
                                    <p>Narodnog Fronta 59,</p>
                                    <p>Novi Sad</p>
                                </div>
                                <div class="results-address-box">
                                    <div class="full-width pull-left results-address-icon phone"></div>
                                    <div class="clr"></div>
                                    <p>064 1234567</p>
                                    <p>Novi Sad</p>
                                </div>
                            </div>
                            <div class="results-address-expand">
                                <div class="results-address-expand-box">
                                    <div class="results-address-box">
                                        <div class="full-width pull-left results-address-icon"></div>
                                        <div class="clr"></div>
                                        <p>Narodnog Fronta 59,</p>
                                        <p>Novi Sad</p>
                                    </div>
                                    <div class="results-address-box">
                                        <div class="full-width pull-left results-address-icon phone"></div>
                                        <div class="clr"></div>
                                        <p>064 1234567</p>
                                        <p>Novi Sad</p>
                                    </div>
                                </div>
                                <div class="results-address-expand-box">
                                    <div class="results-address-box">
                                        <div class="full-width pull-left results-address-icon"></div>
                                        <div class="clr"></div>
                                        <p>Narodnog Fronta 59,</p>
                                        <p>Novi Sad</p>
                                    </div>
                                    <div class="results-address-box">
                                        <div class="full-width pull-left results-address-icon phone"></div>
                                        <div class="clr"></div>
                                        <p>064 1234567</p>
                                        <p>Novi Sad</p>
                                    </div>
                                </div>
                            </div>
                            <div class="results-address-trigger"></div>
                        </div>
                        <div class="pull-right results-message">
                            <a href="#">Posalji poruku</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="results-box result-type-three">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="user-image">
                            <img src="/img/user/user-default.png"  alt="" />
                        </div>
                        <div class="results-user-data">
                            <h4>Petar Petrovic</h4>
                            <div class="clr"></div>
                            <div class="rate">
                                <ul>
                                    <li class="rated"></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li class=""></li>
                                </ul>
                            </div>
                            <div class="clr"></div>
                            <p class="results-job">Vodoinstalater</p>
                        </div>
                        <div class="results-user">
                            <ul class="results-user-list">
                            </ul>
                            <p class="results-user-active">Otvoreno</p>
                            <div class="clr"></div>
                            <span class="results-user-range">2.3 km</span>
                        </div>
                        <div class="results-contacts">
                            <div class="pull-left full-width results-address">
                                <div class="results-address-box">
                                    <div class="full-width pull-left results-address-icon"></div>
                                    <div class="clr"></div>
                                    <p>Narodnog Fronta 59,</p>
                                    <p>Novi Sad</p>
                                </div>
                                <div class="results-address-box">
                                    <div class="full-width pull-left results-address-icon phone"></div>
                                    <div class="clr"></div>
                                    <p>064 1234567</p>
                                    <p>Novi Sad</p>
                                </div>
                            </div>
                            <div class="results-address-expand">
                                <div class="results-address-expand-box">
                                    <div class="results-address-box">
                                        <div class="full-width pull-left results-address-icon"></div>
                                        <div class="clr"></div>
                                        <p>Narodnog Fronta 59,</p>
                                        <p>Novi Sad</p>
                                    </div>
                                    <div class="results-address-box">
                                        <div class="full-width pull-left results-address-icon phone"></div>
                                        <div class="clr"></div>
                                        <p>064 1234567</p>
                                        <p>Novi Sad</p>
                                    </div>
                                </div>
                                <div class="results-address-expand-box">
                                    <div class="results-address-box">
                                        <div class="full-width pull-left results-address-icon"></div>
                                        <div class="clr"></div>
                                        <p>Narodnog Fronta 59,</p>
                                        <p>Novi Sad</p>
                                    </div>
                                    <div class="results-address-box">
                                        <div class="full-width pull-left results-address-icon phone"></div>
                                        <div class="clr"></div>
                                        <p>064 1234567</p>
                                        <p>Novi Sad</p>
                                    </div>
                                </div>
                            </div>
                            <div class="results-address-trigger"></div>
                        </div>
                        <div class="pull-right results-message">
                            <a href="#">Posalji poruku</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="results-box result-type-three">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="user-image">
                            <img src="/img/user/user-default.png"  alt="" />
                        </div>
                        <div class="results-user-data">
                            <h4>Petar Petrovic</h4>
                            <div class="clr"></div>
                            <div class="rate">
                                <ul>
                                    <li class="rated"></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li class=""></li>
                                </ul>
                            </div>
                            <div class="clr"></div>
                            <p class="results-job">Vodoinstalater</p>
                        </div>
                        <div class="results-user">
                            <ul class="results-user-list">
                            </ul>
                            <p class="results-user-active">Otvoreno</p>
                            <div class="clr"></div>
                            <span class="results-user-range">2.3 km</span>
                        </div>
                        <div class="results-contacts">
                            <div class="pull-left full-width results-address">
                                <div class="results-address-box">
                                    <div class="full-width pull-left results-address-icon"></div>
                                    <div class="clr"></div>
                                    <p>Narodnog Fronta 59,</p>
                                    <p>Novi Sad</p>
                                </div>
                                <div class="results-address-box">
                                    <div class="full-width pull-left results-address-icon phone"></div>
                                    <div class="clr"></div>
                                    <p>064 1234567</p>
                                    <p>Novi Sad</p>
                                </div>
                            </div>
                            <div class="results-address-expand">
                                <div class="results-address-expand-box">
                                    <div class="results-address-box">
                                        <div class="full-width pull-left results-address-icon"></div>
                                        <div class="clr"></div>
                                        <p>Narodnog Fronta 59,</p>
                                        <p>Novi Sad</p>
                                    </div>
                                    <div class="results-address-box">
                                        <div class="full-width pull-left results-address-icon phone"></div>
                                        <div class="clr"></div>
                                        <p>064 1234567</p>
                                        <p>Novi Sad</p>
                                    </div>
                                </div>
                                <div class="results-address-expand-box">
                                    <div class="results-address-box">
                                        <div class="full-width pull-left results-address-icon"></div>
                                        <div class="clr"></div>
                                        <p>Narodnog Fronta 59,</p>
                                        <p>Novi Sad</p>
                                    </div>
                                    <div class="results-address-box">
                                        <div class="full-width pull-left results-address-icon phone"></div>
                                        <div class="clr"></div>
                                        <p>064 1234567</p>
                                        <p>Novi Sad</p>
                                    </div>
                                </div>
                            </div>
                            <div class="results-address-trigger"></div>
                        </div>
                        <div class="pull-right results-message">
                            <a href="#">Posalji poruku</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row full-width pagination">
            <div class="col-xs-12">
                <ul class="pull-left full-width">
                    <li class="active"><a href="#">1</a></li>
                    <li><a href="#">2</a></li>
                    <li><a href="#">3</a></li>
                    <li><a href="#">4</a></li>
                    <li><a href="#">5</a></li>
                </ul>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>