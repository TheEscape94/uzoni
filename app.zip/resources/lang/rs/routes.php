<?php

return[
    'registration' => 'rs/registracija',
    'profile' => 'rs/profil-korisnika',
    'company_registration' => 'rs/registracija-firme',
];