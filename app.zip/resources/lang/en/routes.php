<?php

return[
    'registration' => 'en/registration',
    'profile' => 'en/client-profile',
    'company_registration' => 'en/company_registration',
];